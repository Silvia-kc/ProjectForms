﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Models
{
    public class Vehicles
    {
        [Key]
        public int vehicle_id {  get; set; }
        [Required]
        [MaxLength(30)]
        public string brand {  get; set; }
        [Required]
        [MaxLength(50)]
        public string model {  get; set; }
        [Required]
        public int year_of_manifacture {  get; set; }
        [Required]
        [MaxLength(10)]
        public string license_plate {  get; set; }
        [ForeignKey(nameof(client))]
        public int client_id {  get; set; }
        public Clients client { get; set; }
        public List<Repairs> repairs { get; set; }

    }
}
