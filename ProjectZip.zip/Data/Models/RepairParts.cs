﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Models
{
    [PrimaryKey(nameof(repair_id),nameof(part_id))]
    public class RepairParts
    {
        [ForeignKey("Repair")]
        public int repair_id {  get; set; }
        public Repairs repairs { get; set; }
        [ForeignKey("Part")]
        public int part_id {  get; set; }
        public Parts parts { get; set; }
        [Required]
        public int quantity {  get; set; }
    }
}
