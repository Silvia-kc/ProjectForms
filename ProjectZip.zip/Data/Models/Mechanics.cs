﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Data.Models
{
    public class Mechanics
    {
        [Key]
        public int mechanic_id {  get; set; }
        [Required]
        [MaxLength(30)]
        public string first_name {  get; set; }
        [Required]
        [MaxLength(50)]
        public string last_name { get; set; }
        [Required]
        [MaxLength(40)]
        public string specialization {  get; set; }
        public ICollection<RepairMechanics> repair_mechanics { get; set; }
    }
}
