﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Models
{
    public class Repairs
    {
        [Key]
        public int repair_id {  get; set; }
        [Required]
        public DateOnly date_in { get; set; }
        public DateOnly? date_out { get; set; }
        [Required]
        public double total_cost {  get; set; }
        [Required]
        [MaxLength(100)]
        public string repair_type {  get; set; }
        [ForeignKey(nameof(vehicle))]
        public int vehicle_id { get; set; }
        public Vehicles vehicle { get; set; }
        public ICollection<RepairMechanics> repair_mechanics { get; set; }
        public ICollection<RepairParts> repair_parts { get; set; }
    }
}
