﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Models
{
    public class Clients
    {
        [Key]
        public int client_Id {  get; set; }
        [Required]
        [MaxLength(30)]
        public string first_name {  get; set; }
        [Required]
        [MaxLength(50)]
        public string last_name { get; set; }
        [Required]
        [MaxLength(10)]
        public string phone_number {  get; set; }
        [Required]
        [MaxLength(40)]
        public string email { get; set; }
        public List<Vehicles> vehicles { get; set; }
    }
}
