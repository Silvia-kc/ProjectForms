﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Models
{
    public class Parts
    {
        [Key]
        public int part_id {  get; set; }
        [Required]
        [MaxLength(60)]
        public string name { get; set; }
        [Required]
        public double price { get; set; }
        public ICollection<RepairParts> repair_parts { get; set; }
    }
}
