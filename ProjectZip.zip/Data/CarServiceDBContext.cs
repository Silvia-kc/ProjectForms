﻿using Data.Models;
using Microsoft.EntityFrameworkCore;
using ServiceStack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    public class CarServiceDBContext:DbContext
    {
        public CarServiceDBContext() : base()
        {
        }
        public DbSet<Clients> Clients { get; set; }
        public DbSet<Mechanics> Mechanics { get; set; }
        public DbSet<Parts> Parts { get; set; }
        public DbSet<Repairs> Repairs { get; set; }
        public DbSet<Vehicles> Vehicles { get; set; }
        public DbSet<RepairMechanics> RepairMechanic { get; set; }
        public DbSet<RepairParts> RepairParts { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=STUDENT15;Initial Catalog=CarService-Update; Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False");
        }
       
    }
}
