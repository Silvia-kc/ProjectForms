﻿
namespace WinFormsApp1
{
    partial class ClientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClientForm));
            Clientlabel = new Label();
            pictureBox1 = new PictureBox();
            ClientFirstName = new Label();
            ClientFirstNametextBox = new TextBox();
            ClientLastName = new Label();
            ClientLastNametextBox = new TextBox();
            ClientPhoneNumbertextBox = new TextBox();
            ClientPhoneNumber = new Label();
            ClientEmail = new Label();
            ClientEmailtextBox = new TextBox();
            AddClientButton = new Button();
            ViewAllClientslistBox = new ListBox();
            FirstNameForSearch = new Label();
            EnterClientFirstNameForSearchtextBox = new TextBox();
            ViewClientButton = new Button();
            SearchClientListBox = new ListBox();
            AddClientButtonTop = new Button();
            ViewAllClientsTop = new Button();
            SearchClientbutton = new Button();
            ExitClientsbutton = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Clientlabel
            // 
            Clientlabel.AutoSize = true;
            Clientlabel.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Clientlabel.Location = new Point(12, 24);
            Clientlabel.Name = "Clientlabel";
            Clientlabel.Size = new Size(174, 62);
            Clientlabel.TabIndex = 0;
            Clientlabel.Text = "Clients";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(208, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(131, 104);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // ClientFirstName
            // 
            ClientFirstName.AutoSize = true;
            ClientFirstName.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ClientFirstName.Location = new Point(31, 261);
            ClientFirstName.Name = "ClientFirstName";
            ClientFirstName.Size = new Size(198, 23);
            ClientFirstName.TabIndex = 3;
            ClientFirstName.Text = "Enter client first name: ";
            ClientFirstName.Click += ClientFirstName_Click;
            // 
            // ClientFirstNametextBox
            // 
            ClientFirstNametextBox.Location = new Point(224, 257);
            ClientFirstNametextBox.Name = "ClientFirstNametextBox";
            ClientFirstNametextBox.Size = new Size(177, 27);
            ClientFirstNametextBox.TabIndex = 4;
            // 
            // ClientLastName
            // 
            ClientLastName.AutoSize = true;
            ClientLastName.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ClientLastName.Location = new Point(31, 297);
            ClientLastName.Name = "ClientLastName";
            ClientLastName.Size = new Size(188, 23);
            ClientLastName.TabIndex = 5;
            ClientLastName.Text = "Enter client last name:";
            // 
            // ClientLastNametextBox
            // 
            ClientLastNametextBox.Location = new Point(224, 296);
            ClientLastNametextBox.Name = "ClientLastNametextBox";
            ClientLastNametextBox.Size = new Size(177, 27);
            ClientLastNametextBox.TabIndex = 6;
            // 
            // ClientPhoneNumbertextBox
            // 
            ClientPhoneNumbertextBox.Location = new Point(267, 338);
            ClientPhoneNumbertextBox.Name = "ClientPhoneNumbertextBox";
            ClientPhoneNumbertextBox.Size = new Size(177, 27);
            ClientPhoneNumbertextBox.TabIndex = 7;
            // 
            // ClientPhoneNumber
            // 
            ClientPhoneNumber.AutoSize = true;
            ClientPhoneNumber.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ClientPhoneNumber.Location = new Point(31, 339);
            ClientPhoneNumber.Name = "ClientPhoneNumber";
            ClientPhoneNumber.Size = new Size(230, 23);
            ClientPhoneNumber.TabIndex = 9;
            ClientPhoneNumber.Text = "Enter client phone number:";
            // 
            // ClientEmail
            // 
            ClientEmail.AutoSize = true;
            ClientEmail.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ClientEmail.Location = new Point(31, 381);
            ClientEmail.Name = "ClientEmail";
            ClientEmail.Size = new Size(160, 23);
            ClientEmail.TabIndex = 10;
            ClientEmail.Text = "Enter client email: ";
            // 
            // ClientEmailtextBox
            // 
            ClientEmailtextBox.Location = new Point(197, 380);
            ClientEmailtextBox.Name = "ClientEmailtextBox";
            ClientEmailtextBox.Size = new Size(177, 27);
            ClientEmailtextBox.TabIndex = 11;
            // 
            // AddClientButton
            // 
            AddClientButton.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AddClientButton.Location = new Point(349, 438);
            AddClientButton.Name = "AddClientButton";
            AddClientButton.Size = new Size(176, 65);
            AddClientButton.TabIndex = 12;
            AddClientButton.Text = "Add";
            AddClientButton.UseVisualStyleBackColor = true;
            AddClientButton.Click += AddClientButton_Click;
            // 
            // ViewAllClientslistBox
            // 
            ViewAllClientslistBox.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllClientslistBox.FormattingEnabled = true;
            ViewAllClientslistBox.Location = new Point(619, 583);
            ViewAllClientslistBox.Name = "ViewAllClientslistBox";
            ViewAllClientslistBox.Size = new Size(569, 344);
            ViewAllClientslistBox.TabIndex = 13;
            ViewAllClientslistBox.SelectedIndexChanged += ViewAllClientslistBox_SelectedIndexChanged;
            // 
            // FirstNameForSearch
            // 
            FirstNameForSearch.AutoSize = true;
            FirstNameForSearch.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            FirstNameForSearch.Location = new Point(1309, 213);
            FirstNameForSearch.Name = "FirstNameForSearch";
            FirstNameForSearch.Size = new Size(300, 25);
            FirstNameForSearch.TabIndex = 15;
            FirstNameForSearch.Text = "Enter client first name for search: ";
            // 
            // EnterClientFirstNameForSearchtextBox
            // 
            EnterClientFirstNameForSearchtextBox.Location = new Point(1340, 257);
            EnterClientFirstNameForSearchtextBox.Name = "EnterClientFirstNameForSearchtextBox";
            EnterClientFirstNameForSearchtextBox.Size = new Size(243, 27);
            EnterClientFirstNameForSearchtextBox.TabIndex = 16;
            // 
            // ViewClientButton
            // 
            ViewClientButton.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewClientButton.Location = new Point(1655, 381);
            ViewClientButton.Name = "ViewClientButton";
            ViewClientButton.Size = new Size(235, 58);
            ViewClientButton.TabIndex = 17;
            ViewClientButton.Text = "View client";
            ViewClientButton.UseVisualStyleBackColor = true;
            ViewClientButton.Click += ViewAllClientsButton2_Click;
            // 
            // SearchClientListBox
            // 
            SearchClientListBox.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchClientListBox.FormattingEnabled = true;
            SearchClientListBox.ItemHeight = 25;
            SearchClientListBox.Location = new Point(964, 308);
            SearchClientListBox.Name = "SearchClientListBox";
            SearchClientListBox.Size = new Size(871, 54);
            SearchClientListBox.TabIndex = 18;
            // 
            // AddClientButtonTop
            // 
            AddClientButtonTop.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AddClientButtonTop.Location = new Point(59, 172);
            AddClientButtonTop.Name = "AddClientButtonTop";
            AddClientButtonTop.Size = new Size(280, 53);
            AddClientButtonTop.TabIndex = 19;
            AddClientButtonTop.Text = "Add client";
            AddClientButtonTop.UseVisualStyleBackColor = true;
            AddClientButtonTop.Click += AddClientButtonTop_Click;
            // 
            // ViewAllClientsTop
            // 
            ViewAllClientsTop.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllClientsTop.Location = new Point(730, 493);
            ViewAllClientsTop.Name = "ViewAllClientsTop";
            ViewAllClientsTop.Size = new Size(369, 62);
            ViewAllClientsTop.TabIndex = 20;
            ViewAllClientsTop.Text = "View all clients";
            ViewAllClientsTop.UseVisualStyleBackColor = true;
            ViewAllClientsTop.Click += ViewAllClientsTop_Click;
            // 
            // SearchClientbutton
            // 
            SearchClientbutton.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchClientbutton.Location = new Point(1279, 125);
            SearchClientbutton.Name = "SearchClientbutton";
            SearchClientbutton.Size = new Size(345, 53);
            SearchClientbutton.TabIndex = 21;
            SearchClientbutton.Text = "Search client by first name";
            SearchClientbutton.UseVisualStyleBackColor = true;
            SearchClientbutton.Click += SearchClientbutton_Click;
            // 
            // ExitClientsbutton
            // 
            ExitClientsbutton.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ExitClientsbutton.Location = new Point(12, 950);
            ExitClientsbutton.Name = "ExitClientsbutton";
            ExitClientsbutton.Size = new Size(194, 71);
            ExitClientsbutton.TabIndex = 22;
            ExitClientsbutton.Text = "Exit";
            ExitClientsbutton.UseVisualStyleBackColor = true;
            ExitClientsbutton.Click += ExitClientbutton_Click;
            // 
            // ClientForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1902, 1033);
            Controls.Add(ExitClientsbutton);
            Controls.Add(SearchClientbutton);
            Controls.Add(ViewAllClientsTop);
            Controls.Add(AddClientButtonTop);
            Controls.Add(SearchClientListBox);
            Controls.Add(ViewClientButton);
            Controls.Add(EnterClientFirstNameForSearchtextBox);
            Controls.Add(FirstNameForSearch);
            Controls.Add(ViewAllClientslistBox);
            Controls.Add(AddClientButton);
            Controls.Add(ClientEmailtextBox);
            Controls.Add(ClientEmail);
            Controls.Add(ClientPhoneNumber);
            Controls.Add(ClientPhoneNumbertextBox);
            Controls.Add(ClientLastNametextBox);
            Controls.Add(ClientLastName);
            Controls.Add(ClientFirstNametextBox);
            Controls.Add(ClientFirstName);
            Controls.Add(pictureBox1);
            Controls.Add(Clientlabel);
            Name = "ClientForm";
            Text = "Form2";
            Load += ClientForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void ClientFirstName_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

      

        #endregion

        private Label Clientlabel;
        private PictureBox pictureBox1;
        private Label ClientFirstName;
        private TextBox ClientFirstNametextBox;
        private Label ClientLastName;
        private TextBox ClientLastNametextBox;
        private TextBox ClientPhoneNumbertextBox;
        private Label ClientPhoneNumber;
        private Label ClientEmail;
        private TextBox ClientEmailtextBox;
        private Button AddClientButton;
        private ListBox ViewAllClientslistBox;
        private Label FirstNameForSearch;
        private TextBox EnterClientFirstNameForSearchtextBox;
        private Button ViewClientButton;
        private ListBox SearchClientListBox;
        private Button AddClientButtonTop;
        private Button ViewAllClientsTop;
        private Button SearchClientbutton;
        private Button ExitClientsbutton;
    }
}