﻿using Core;
using Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class MechanicForm : Form
    {
        MechanicController mechanicController = new MechanicController();
        public MechanicForm()
        {
            InitializeComponent();
        }

        private void MechanicForm_Load(object sender, EventArgs e)
        {
            MechanicFirstName.Visible = false;
            MechanicFirstNametextBox.Visible = false;
            MechanicLastName.Visible = false;
            MechanicLastNametextBox.Visible = false;
            MechanicSpecialization.Visible = false;
            MechanicSpecializationtextBox.Visible = false;
            AddMechanicbutton.Visible = false;
            ViewAllMechanicslistBox.Visible = false;
            ViewBusiestMechaniclistBox.Visible = false;
        }

        private void AddMechanicbuttonTop_Click(object sender, EventArgs e)
        {
            MechanicFirstName.Show();
            MechanicFirstNametextBox.Show();
            MechanicLastName.Show();
            MechanicLastNametextBox.Show();
            MechanicSpecialization.Show();
            MechanicSpecializationtextBox.Show();
            AddMechanicbutton.Show();
        }

        private void AddMechanicbutton_Click(object sender, EventArgs e)
        {
            string firstName = MechanicFirstNametextBox.Text;
            string lastName = MechanicLastNametextBox.Text;
            string specialization = MechanicSpecializationtextBox.Text;
            mechanicController.AddMechanic(firstName, lastName, specialization);
        }

        private async void ViewAllMechanics_Click(object sender, EventArgs e)
        {
            ViewAllMechanicslistBox.Show();
            List<Mechanics> mechanics = await mechanicController.GetAllMechanics();

            foreach (var mechanic in mechanics)
            {
                ViewAllMechanicslistBox.Items.Add($"{mechanic.mechanic_id}. {mechanic.first_name} {mechanic.last_name}. Specialized in {mechanic.specialization}");
            }

        }

        private async void ViewBusiestMechanic_Click(object sender, EventArgs e)
        {
            ViewBusiestMechaniclistBox.Show();
            var mechanic = await mechanicController.BusiestMechanic();
            ViewBusiestMechaniclistBox.Items.Add($"{mechanic.first_name} {mechanic.last_name}");

        }

        private void ExitMechanicsbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
