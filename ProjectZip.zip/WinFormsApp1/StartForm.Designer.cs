﻿namespace WinFormsApp1
{
    partial class StartForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StartForm));
            label1 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            ShowMenu = new Button();
            pictureBox5 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox9 = new PictureBox();
            pictureBox10 = new PictureBox();
            Clientsbutton = new Button();
            Mechanicsbutton = new Button();
            Partsbutton = new Button();
            Repairsbutton = new Button();
            Vehiclesbutton = new Button();
            pictureBox6 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(713, 203);
            label1.Name = "label1";
            label1.Size = new Size(435, 69);
            label1.TabIndex = 0;
            label1.Text = "CAR SERVICE";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(1629, 160);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(109, 94);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(156, 292);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(122, 105);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(1552, 400);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(97, 91);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 3;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(1629, 797);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(93, 92);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 4;
            pictureBox4.TabStop = false;
            // 
            // ShowMenu
            // 
            ShowMenu.BackColor = Color.LightCyan;
            ShowMenu.Font = new Font("Sylfaen", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ShowMenu.Location = new Point(831, 275);
            ShowMenu.Name = "ShowMenu";
            ShowMenu.Size = new Size(188, 64);
            ShowMenu.TabIndex = 5;
            ShowMenu.Text = "Show Menu";
            ShowMenu.UseVisualStyleBackColor = false;
            ShowMenu.Click += ShowMenu_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(423, 87);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(105, 101);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 6;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(203, 805);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(96, 94);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 8;
            pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(1190, 87);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(92, 86);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 9;
            pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(790, 738);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(123, 102);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 10;
            pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(1257, 702);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(112, 112);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 11;
            pictureBox10.TabStop = false;
            // 
            // Clientsbutton
            // 
            Clientsbutton.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Clientsbutton.Location = new Point(620, 341);
            Clientsbutton.Name = "Clientsbutton";
            Clientsbutton.Size = new Size(168, 56);
            Clientsbutton.TabIndex = 12;
            Clientsbutton.Text = "👥 Clients";
            Clientsbutton.UseVisualStyleBackColor = true;
            Clientsbutton.Click += Clientsbutton_Click;
            // 
            // Mechanicsbutton
            // 
            Mechanicsbutton.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Mechanicsbutton.Location = new Point(1029, 348);
            Mechanicsbutton.Name = "Mechanicsbutton";
            Mechanicsbutton.Size = new Size(188, 49);
            Mechanicsbutton.TabIndex = 13;
            Mechanicsbutton.Text = "👨‍🔧 Mechanics";
            Mechanicsbutton.UseVisualStyleBackColor = true;
            Mechanicsbutton.Click += Mechanicsbutton_Click;
            // 
            // Partsbutton
            // 
            Partsbutton.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Partsbutton.Location = new Point(665, 512);
            Partsbutton.Name = "Partsbutton";
            Partsbutton.Size = new Size(191, 54);
            Partsbutton.TabIndex = 14;
            Partsbutton.Text = "🔩 Parts";
            Partsbutton.UseVisualStyleBackColor = true;
            Partsbutton.Click += Partsbutton_Click;
            // 
            // Repairsbutton
            // 
            Repairsbutton.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Repairsbutton.Location = new Point(822, 410);
            Repairsbutton.Name = "Repairsbutton";
            Repairsbutton.Size = new Size(197, 63);
            Repairsbutton.TabIndex = 17;
            Repairsbutton.Text = "🔧 Repairs";
            Repairsbutton.UseVisualStyleBackColor = true;
            Repairsbutton.Click += Repairsbutton_Click;
            // 
            // Vehiclesbutton
            // 
            Vehiclesbutton.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Vehiclesbutton.Location = new Point(1041, 512);
            Vehiclesbutton.Name = "Vehiclesbutton";
            Vehiclesbutton.Size = new Size(214, 59);
            Vehiclesbutton.TabIndex = 18;
            Vehiclesbutton.Text = "🚗 Vehicles";
            Vehiclesbutton.UseVisualStyleBackColor = true;
            Vehiclesbutton.Click += Vehiclesbutton_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(423, 530);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(121, 105);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 7;
            pictureBox6.TabStop = false;
            // 
            // StartForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1902, 1033);
            Controls.Add(Vehiclesbutton);
            Controls.Add(Repairsbutton);
            Controls.Add(Partsbutton);
            Controls.Add(Mechanicsbutton);
            Controls.Add(Clientsbutton);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox9);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(ShowMenu);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Name = "StartForm";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private Button ShowMenu;
        private PictureBox pictureBox5;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private Button Clientsbutton;
        private Button Mechanicsbutton;
        private Button Partsbutton;
        private Button Repairsbutton;
        private Button Vehiclesbutton;
        private PictureBox pictureBox6;
    }
}
