﻿using ConsoleApp;
using Core;
using Data;
using Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class ClientForm : Form
    {
        public static CarServiceDBContext context = new CarServiceDBContext();
        ClientController clientController = new ClientController();
        ClientDisplay clientDisplay = new ClientDisplay();
        public ClientForm()
        {
            InitializeComponent();
        }


        private void ClientForm_Load(object sender, EventArgs e)
        {
            ClientFirstName.Visible = false;
            ClientFirstNametextBox.Visible = false;
            ClientLastName.Visible = false;
            ClientLastNametextBox.Visible = false;
            ClientPhoneNumber.Visible = false;
            ClientPhoneNumbertextBox.Visible = false;
            ClientEmail.Visible = false;
            ClientEmailtextBox.Visible = false;
            AddClientButton.Visible = false;
            ViewAllClientslistBox.Visible = false;
            ViewClientButton.Visible = false;
            FirstNameForSearch.Visible = false;
            EnterClientFirstNameForSearchtextBox.Visible = false;
            SearchClientListBox.Visible = false;
            ViewAllClientslistBox.Visible = false;
        }

        private async void ViewAllClientslistBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private async void ViewAllClientsButton2_Click(object sender, EventArgs e)
        {
            string firstName = EnterClientFirstNameForSearchtextBox.Text;
            Clients client = await clientController.SearchClientByFirstName(firstName);
            SearchClientListBox.Items.Add($" {client.first_name} {client.last_name}. Client contact: phone numebr: {client.phone_number}, email: {client.email}");
        }

        private void AddClientButtonTop_Click(object sender, EventArgs e)
        {
            ClientFirstName.Show();
            ClientFirstNametextBox.Show();
            ClientLastName.Show();
            ClientLastNametextBox.Show();
            ClientPhoneNumber.Show();
            ClientPhoneNumbertextBox.Show();
            ClientEmail.Show();
            ClientEmailtextBox.Show();
            AddClientButton.Show();

        }

        private async void ViewAllClientsTop_Click(object sender, EventArgs e)
        {
            ViewAllClientslistBox.Show();
            List<Clients> clients = await clientController.GetAllClients();

            foreach (var client in clients)
            {
                ViewAllClientslistBox.Items.Add($"{client.first_name} {client.last_name}. Contact: {client.phone_number}, {client.email}");
            }
        }

        private void AddClientButton_Click(object sender, EventArgs e)
        {
            string firstName = ClientFirstNametextBox.Text;
            string lastName = ClientLastNametextBox.Text;
            string phoneNumber = ClientPhoneNumbertextBox.Text;
            string email = ClientEmailtextBox.Text;
            clientController.AddClient(firstName, lastName, phoneNumber, email);
        }

        private void SearchClientbutton_Click(object sender, EventArgs e)
        {
            ViewClientButton.Show();
            FirstNameForSearch.Show();
            EnterClientFirstNameForSearchtextBox.Show();
            SearchClientListBox.Show();
        }

        private void ExitClientbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
