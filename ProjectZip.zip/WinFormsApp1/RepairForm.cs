﻿using Core;
using Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class RepairForm : Form
    {
        RepairController repairController = new RepairController();
        public RepairForm()
        {
            InitializeComponent();
        }

        private void RepairTotalCost_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddRepairbuttonTop_Click(object sender, EventArgs e)
        {
            RepairDateIn.Show();
            RepairDateIntextBox.Show();
            RepairDateOut.Show();
            RepairDateOuttextBox.Show();
            RepairTotalCost.Show();
            RepairTotalCosttextBox.Show();
            RepairType.Show();
            RepairTypetextBox.Show();
            RepairVehicleId.Show();
            RepairVehileIdtextBox.Show();
            AddRepairButton.Show();
        }

        private void RepairForm_Load(object sender, EventArgs e)
        {
            RepairDateIn.Visible = false;
            RepairDateIntextBox.Visible = false;
            RepairDateOut.Visible = false;
            RepairDateOuttextBox.Visible = false;
            RepairTotalCost.Visible = false;
            RepairTotalCosttextBox.Visible = false;
            RepairType.Visible = false;
            RepairTypetextBox.Visible = false;
            RepairVehicleId.Visible = false;
            RepairVehileIdtextBox.Visible = false;
            AddRepairButton.Visible = false;
            ViewAllRepairslistBox.Visible = false;
            VehicleIdForSearch.Visible = false;
            VehicleIdForSeachtextBox.Visible = false;
            RepairVehiclelistBox.Visible = false;
            ViewRepairsbutton.Visible = false;
            ClientId.Visible = false;
            ClientIdForSearchtextBox.Visible = false;
            TotalCostlistBox.Visible = false;
            TotalCostbutton.Visible = false;

            EnterYear.Visible = false;
            YeartextBox.Visible = false;
            TotalCostYearlistBox.Visible = false;
            TotalCostForYearbutton.Visible = false;
        }

        private void AddRepairButton_Click(object sender, EventArgs e)
        {
            DateOnly dateIn = DateOnly.Parse(RepairDateIntextBox.Text);
            DateOnly dateOut = DateOnly.Parse(RepairDateOuttextBox.Text);
            double totalCost = double.Parse(RepairTotalCosttextBox.Text);
            string repairType = RepairTypetextBox.Text;
            int vehicleId = int.Parse(RepairVehileIdtextBox.Text);
            repairController.AddRepair(dateIn, dateOut, totalCost, repairType, vehicleId);
        }

        private async void ViewAllRepairs_Click(object sender, EventArgs e)
        {
            ViewAllRepairslistBox.Show();
            List<Repairs> repairs = await repairController.ViewAllReapirs();
            foreach (var repair in repairs)
            {
                ViewAllRepairslistBox.Items.Add($"Entered on: {repair.date_in}. Out on: {repair.date_out}. Reapir type: {repair.repair_type} - {repair.total_cost} lv.");
            }
        }

        private void ViewAllRepairslistBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ViewAllRepairsForVehicle_Click(object sender, EventArgs e)
        {
            VehicleIdForSearch.Show();
            VehicleIdForSeachtextBox.Show();
            RepairVehiclelistBox.Show();
            ViewRepairsbutton.Show();
        }

        private async void ViewRepairsbutton_Click(object sender, EventArgs e)
        {
            int vehicleId = int.Parse(VehicleIdForSeachtextBox.Text);
            List<Repairs> repairs = await repairController.AllRepairsForVehcile(vehicleId);
            foreach (var repair in repairs)
            {
                RepairVehiclelistBox.Items.Add($"{repair.repair_type} - {repair.total_cost} lv.");
            }
        }

        private void ViewTotalCostbutton_Click(object sender, EventArgs e)
        {
            ClientId.Show();
            ClientIdForSearchtextBox.Show();
            TotalCostlistBox.Show();
            TotalCostbutton.Show();
        }

        private async void TotalCostbutton_Click(object sender, EventArgs e)
        {
            int clientId = int.Parse(ClientIdForSearchtextBox.Text);
            double totalCost = await repairController.TotalCostOfRepairsForClient(clientId);
            TotalCostlistBox.Items.Add($"{totalCost} lv.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EnterYear.Show();
            YeartextBox.Show();
            TotalCostYearlistBox.Show();
            TotalCostForYearbutton.Show();
        }

        private async void TotalCostForYearbutton_Click(object sender, EventArgs e)
        {
            int year = int.Parse(YeartextBox.Text);
            double totalCost = await repairController.TotalCostOfRepairsForYear(year);
            TotalCostYearlistBox.Items.Add($"{totalCost} lv.");
        }

        private void ExitRepairsbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
