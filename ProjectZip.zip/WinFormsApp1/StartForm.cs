namespace WinFormsApp1
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        private void ShowMenu_Click(object sender, EventArgs e)
        {
            /*Form2 form2 = new Form2();
            form2.Show();*/

            Clientsbutton.Show();
            Partsbutton.Show();
            Repairsbutton.Show();
            Mechanicsbutton.Show();
            Vehiclesbutton.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Clientsbutton.Visible = false;
            Partsbutton.Visible = false;
            Repairsbutton.Visible = false;
            Mechanicsbutton.Visible = false;
            Vehiclesbutton.Visible = false;
        }

        private void Clientsbutton_Click(object sender, EventArgs e)
        {
            ClientForm clientForm = new ClientForm();
            clientForm.Show();
        }

        private void Mechanicsbutton_Click(object sender, EventArgs e)
        {
            MechanicForm mechanicForm = new MechanicForm();
            mechanicForm.Show();
        }

        private void Partsbutton_Click(object sender, EventArgs e)
        {
            PartForm partForm = new PartForm();
            partForm.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void Vehiclesbutton_Click(object sender, EventArgs e)
        {
            VehicleForm vehicleForm = new VehicleForm();
            vehicleForm.Show();
        }

        private void Repairsbutton_Click(object sender, EventArgs e)
        {
            RepairForm repairForm = new RepairForm();
            repairForm.Show();
        }
    }
}
