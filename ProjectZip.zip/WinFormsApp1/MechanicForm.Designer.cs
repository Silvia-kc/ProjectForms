﻿namespace WinFormsApp1
{
    partial class MechanicForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MechanicForm));
            Mechaniclabel = new Label();
            pictureBox1 = new PictureBox();
            AddMechanicbuttonTop = new Button();
            MechanicFirstName = new Label();
            MechanicFirstNametextBox = new TextBox();
            MechanicLastName = new Label();
            MechanicLastNametextBox = new TextBox();
            MechanicSpecialization = new Label();
            MechanicSpecializationtextBox = new TextBox();
            AddMechanicbutton = new Button();
            ViewAllMechanics = new Button();
            ViewAllMechanicslistBox = new ListBox();
            ViewBusiestMechanic = new Button();
            ViewBusiestMechaniclistBox = new ListBox();
            ExitMechanicsbutton = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Mechaniclabel
            // 
            Mechaniclabel.AutoSize = true;
            Mechaniclabel.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Mechaniclabel.Location = new Point(12, 37);
            Mechaniclabel.Name = "Mechaniclabel";
            Mechaniclabel.Size = new Size(233, 62);
            Mechaniclabel.TabIndex = 0;
            Mechaniclabel.Text = "Mechnics";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(251, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(105, 114);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // AddMechanicbuttonTop
            // 
            AddMechanicbuttonTop.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AddMechanicbuttonTop.Location = new Point(78, 177);
            AddMechanicbuttonTop.Name = "AddMechanicbuttonTop";
            AddMechanicbuttonTop.Size = new Size(223, 52);
            AddMechanicbuttonTop.TabIndex = 2;
            AddMechanicbuttonTop.Text = "Add mechanic";
            AddMechanicbuttonTop.UseVisualStyleBackColor = true;
            AddMechanicbuttonTop.Click += AddMechanicbuttonTop_Click;
            // 
            // MechanicFirstName
            // 
            MechanicFirstName.AutoSize = true;
            MechanicFirstName.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            MechanicFirstName.Location = new Point(24, 254);
            MechanicFirstName.Name = "MechanicFirstName";
            MechanicFirstName.Size = new Size(229, 23);
            MechanicFirstName.TabIndex = 4;
            MechanicFirstName.Text = "Enter mechanic first name: ";
            // 
            // MechanicFirstNametextBox
            // 
            MechanicFirstNametextBox.Location = new Point(251, 254);
            MechanicFirstNametextBox.Name = "MechanicFirstNametextBox";
            MechanicFirstNametextBox.Size = new Size(203, 27);
            MechanicFirstNametextBox.TabIndex = 5;
            // 
            // MechanicLastName
            // 
            MechanicLastName.AutoSize = true;
            MechanicLastName.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            MechanicLastName.Location = new Point(26, 297);
            MechanicLastName.Name = "MechanicLastName";
            MechanicLastName.Size = new Size(219, 23);
            MechanicLastName.TabIndex = 6;
            MechanicLastName.Text = "Enter mechanic last name:";
            // 
            // MechanicLastNametextBox
            // 
            MechanicLastNametextBox.Location = new Point(251, 293);
            MechanicLastNametextBox.Name = "MechanicLastNametextBox";
            MechanicLastNametextBox.Size = new Size(204, 27);
            MechanicLastNametextBox.TabIndex = 7;
            // 
            // MechanicSpecialization
            // 
            MechanicSpecialization.AutoSize = true;
            MechanicSpecialization.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            MechanicSpecialization.Location = new Point(24, 343);
            MechanicSpecialization.Name = "MechanicSpecialization";
            MechanicSpecialization.Size = new Size(250, 23);
            MechanicSpecialization.TabIndex = 8;
            MechanicSpecialization.Text = "Enter mechanic specialization:";
            // 
            // MechanicSpecializationtextBox
            // 
            MechanicSpecializationtextBox.Location = new Point(280, 343);
            MechanicSpecializationtextBox.Name = "MechanicSpecializationtextBox";
            MechanicSpecializationtextBox.Size = new Size(204, 27);
            MechanicSpecializationtextBox.TabIndex = 9;
            // 
            // AddMechanicbutton
            // 
            AddMechanicbutton.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AddMechanicbutton.Location = new Point(391, 395);
            AddMechanicbutton.Name = "AddMechanicbutton";
            AddMechanicbutton.Size = new Size(201, 69);
            AddMechanicbutton.TabIndex = 10;
            AddMechanicbutton.Text = "Add";
            AddMechanicbutton.UseVisualStyleBackColor = true;
            AddMechanicbutton.Click += AddMechanicbutton_Click;
            // 
            // ViewAllMechanics
            // 
            ViewAllMechanics.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllMechanics.Location = new Point(721, 450);
            ViewAllMechanics.Name = "ViewAllMechanics";
            ViewAllMechanics.Size = new Size(387, 68);
            ViewAllMechanics.TabIndex = 11;
            ViewAllMechanics.Text = "View all mechanics";
            ViewAllMechanics.UseVisualStyleBackColor = true;
            ViewAllMechanics.Click += ViewAllMechanics_Click;
            // 
            // ViewAllMechanicslistBox
            // 
            ViewAllMechanicslistBox.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllMechanicslistBox.FormattingEnabled = true;
            ViewAllMechanicslistBox.Location = new Point(704, 544);
            ViewAllMechanicslistBox.Name = "ViewAllMechanicslistBox";
            ViewAllMechanicslistBox.Size = new Size(428, 404);
            ViewAllMechanicslistBox.TabIndex = 12;
            // 
            // ViewBusiestMechanic
            // 
            ViewBusiestMechanic.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewBusiestMechanic.Location = new Point(1447, 177);
            ViewBusiestMechanic.Name = "ViewBusiestMechanic";
            ViewBusiestMechanic.Size = new Size(331, 72);
            ViewBusiestMechanic.TabIndex = 13;
            ViewBusiestMechanic.Text = "View busiest mechanic";
            ViewBusiestMechanic.UseVisualStyleBackColor = true;
            ViewBusiestMechanic.Click += ViewBusiestMechanic_Click;
            // 
            // ViewBusiestMechaniclistBox
            // 
            ViewBusiestMechaniclistBox.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewBusiestMechaniclistBox.FormattingEnabled = true;
            ViewBusiestMechaniclistBox.Location = new Point(1399, 279);
            ViewBusiestMechaniclistBox.Name = "ViewBusiestMechaniclistBox";
            ViewBusiestMechaniclistBox.Size = new Size(445, 64);
            ViewBusiestMechaniclistBox.TabIndex = 14;
            // 
            // ExitMechanicsbutton
            // 
            ExitMechanicsbutton.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ExitMechanicsbutton.Location = new Point(12, 951);
            ExitMechanicsbutton.Name = "ExitMechanicsbutton";
            ExitMechanicsbutton.Size = new Size(182, 70);
            ExitMechanicsbutton.TabIndex = 15;
            ExitMechanicsbutton.Text = "Exit";
            ExitMechanicsbutton.UseVisualStyleBackColor = true;
            ExitMechanicsbutton.Click += ExitMechanicsbutton_Click;
            // 
            // MechanicForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1902, 1033);
            Controls.Add(ExitMechanicsbutton);
            Controls.Add(ViewBusiestMechaniclistBox);
            Controls.Add(ViewBusiestMechanic);
            Controls.Add(ViewAllMechanicslistBox);
            Controls.Add(ViewAllMechanics);
            Controls.Add(AddMechanicbutton);
            Controls.Add(MechanicSpecializationtextBox);
            Controls.Add(MechanicSpecialization);
            Controls.Add(MechanicLastNametextBox);
            Controls.Add(MechanicLastName);
            Controls.Add(MechanicFirstNametextBox);
            Controls.Add(MechanicFirstName);
            Controls.Add(AddMechanicbuttonTop);
            Controls.Add(pictureBox1);
            Controls.Add(Mechaniclabel);
            Name = "MechanicForm";
            Text = "MechanicForm";
            Load += MechanicForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Mechaniclabel;
        private PictureBox pictureBox1;
        private Button AddMechanicbuttonTop;
        private Label MechanicFirstName;
        private TextBox MechanicFirstNametextBox;
        private Label MechanicLastName;
        private TextBox MechanicLastNametextBox;
        private Label MechanicSpecialization;
        private TextBox MechanicSpecializationtextBox;
        private Button AddMechanicbutton;
        private Button ViewAllMechanics;
        private ListBox ViewAllMechanicslistBox;
        private Button ViewBusiestMechanic;
        private ListBox ViewBusiestMechaniclistBox;
        private Button ExitMechanicsbutton;
    }
}