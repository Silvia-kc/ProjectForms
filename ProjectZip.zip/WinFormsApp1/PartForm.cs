﻿using Core;
using Data.Models;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class PartForm : Form
    {
        PartController partController = new PartController();
        public PartForm()
        {
            InitializeComponent();
        }

        private void Parts_Load(object sender, EventArgs e)
        {
            PartName.Visible = false;
            PartNametextBox.Visible = false;
            PartPrice.Visible = false;
            PartPricetextBox.Visible = false;
            AddPartButton.Visible = false;
            ViewAllPartslistBox.Visible = false;
            ViewMostCmmonlyUsedPartlistBox.Visible = false;
        }

        private void AddPartbuttonTop_Click(object sender, EventArgs e)
        {
            PartName.Show();
            PartNametextBox.Show();
            PartPrice.Show();
            PartPricetextBox.Show();
            AddPartButton.Show();
        }

        private void AddPartButton_Click(object sender, EventArgs e)
        {
            string name = PartNametextBox.Text;
            double price = double.Parse(PartPricetextBox.Text);
            partController.AddPart(name, price);
        }

        private async void ViewAllParts_Click(object sender, EventArgs e)
        {
            ViewAllPartslistBox.Show();
            List<Parts> parts = await partController.GetAllParts();

            foreach (var part in parts)
            {
                ViewAllPartslistBox.Items.Add($"{part.name} - {part.price} lv.");
            }
        }

        private async void ViewMostCommonlyUsedPart_Click(object sender, EventArgs e)
        {
            ViewMostCmmonlyUsedPartlistBox.Show();
            var part = await partController.MostCommonlyUsedPart();
            ViewMostCmmonlyUsedPartlistBox.Items.Add($"{part.name} - {part.price}");
        }

        private void ExitPartsbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
