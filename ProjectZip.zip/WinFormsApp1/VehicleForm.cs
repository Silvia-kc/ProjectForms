﻿using Core;
using Data.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class VehicleForm : Form
    {
        VehicleController vehicleController = new VehicleController();
        public VehicleForm()
        {
            InitializeComponent();
        }

        private void AddVehiclebuttonTop_Click(object sender, EventArgs e)
        {
            VehicleBrand.Show();
            VehicleBrandtextBox.Show();
            VehicleModel.Show();
            VehicleModeltextBox.Show();
            VehicleYearOfManifacture.Show();
            VehicleYearOfManifacturetextBox.Show();
            VehicleLicensePlate.Show();
            VehicleLicensePlatetextBox.Show();
            VehicleClientId.Show();
            VehicleClientIdtextBox.Show();
            AddVehiclebutton.Show();
        }

        private void VehicleForm_Load(object sender, EventArgs e)
        {
            VehicleBrand.Visible = false;
            VehicleBrandtextBox.Visible = false;
            VehicleModel.Visible = false;
            VehicleModeltextBox.Visible = false;
            VehicleYearOfManifacture.Visible = false;
            VehicleYearOfManifacturetextBox.Visible = false;
            VehicleLicensePlate.Visible = false;
            VehicleLicensePlatetextBox.Visible = false;
            VehicleClientId.Visible = false;
            VehicleClientIdtextBox.Visible = false;
            AddVehiclebutton.Visible = false;
            ViewAllVehicleslistBox.Visible = false;
            ClientIdForSearch.Visible = false;
            ClientIdForSearchtextBox.Visible = false;
            VehicleClientIdtextBox.Visible = false;
            ViewVehicles.Visible = false;
            VehicleClientslistBox.Visible = false;
            MostVisitedCarBrandlistBox.Visible = false;


        }

        private void AddVehiclebutton_Click(object sender, EventArgs e)
        {
            string brand = VehicleBrandtextBox.Text;
            string model = VehicleModeltextBox.Text;
            int yearOfManifacture = int.Parse(VehicleYearOfManifacturetextBox.Text);
            string licensePlate = VehicleLicensePlatetextBox.Text;
            int clientId = int.Parse(VehicleClientIdtextBox.Text);
            vehicleController.AddVehicle(brand, model, yearOfManifacture, licensePlate, clientId);
        }

        private async void ViewAllVehicles_Click(object sender, EventArgs e)
        {
            ViewAllVehicleslistBox.Show();
            List<Vehicles> vehicles = await vehicleController.ViewAllVehicles();
            foreach (var vehicle in vehicles)
            {
                ViewAllVehicleslistBox.Items.Add($"{vehicle.brand} {vehicle.model} manufactured in {vehicle.year_of_manifacture}. Vehicle with license plate {vehicle.license_plate} belongiong to client wit id {vehicle.client_id}");
            }

        }

        private void ViewAllVehiclesAboutClient_Click(object sender, EventArgs e)
        {
            ClientIdForSearch.Show();
            ClientIdForSearchtextBox.Show();
            VehicleClientslistBox.Show();
            ViewVehicles.Show();
        }

        private async void ViewVehicles_Click(object sender, EventArgs e)
        {
            int clientId = int.Parse(ClientIdForSearchtextBox.Text);
            List<Vehicles> vehicles = await vehicleController.AllClientVehicles(clientId);
            foreach (var vehicle in vehicles)
            {
                VehicleClientslistBox.Items.Add($"{vehicle.brand} {vehicle.model} - {vehicle.license_plate}");
            }
        }

        private async void MostVisitedCarBrand_Click(object sender, EventArgs e)
        {
            MostVisitedCarBrandlistBox.Show();
            string brand = await vehicleController.MostVisitedCarBrand();
            MostVisitedCarBrandlistBox.Items.Add($"{brand}");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
