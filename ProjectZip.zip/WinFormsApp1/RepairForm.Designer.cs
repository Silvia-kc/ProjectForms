﻿namespace WinFormsApp1
{
    partial class RepairForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RepairForm));
            Repairslabel = new Label();
            pictureBox1 = new PictureBox();
            AddRepairbuttonTop = new Button();
            RepairDateIn = new Label();
            RepairDateIntextBox = new TextBox();
            RepairDateOut = new Label();
            RepairDateOuttextBox = new TextBox();
            RepairTotalCost = new Label();
            RepairTotalCosttextBox = new TextBox();
            RepairType = new Label();
            RepairTypetextBox = new TextBox();
            RepairVehicleId = new Label();
            RepairVehileIdtextBox = new TextBox();
            AddRepairButton = new Button();
            ViewAllRepairs = new Button();
            ViewAllRepairslistBox = new ListBox();
            ViewAllRepairsForVehicle = new Button();
            VehicleIdForSearch = new Label();
            VehicleIdForSeachtextBox = new TextBox();
            RepairVehiclelistBox = new ListBox();
            ViewRepairsbutton = new Button();
            ViewTotalCostbutton = new Button();
            ClientId = new Label();
            ClientIdForSearchtextBox = new TextBox();
            TotalCostlistBox = new ListBox();
            TotalCostbutton = new Button();
            button2 = new Button();
            EnterYear = new Label();
            YeartextBox = new TextBox();
            TotalCostYearlistBox = new ListBox();
            TotalCostForYearbutton = new Button();
            ExitRepairsbutton = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Repairslabel
            // 
            Repairslabel.AutoSize = true;
            Repairslabel.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Repairslabel.Location = new Point(12, 26);
            Repairslabel.Name = "Repairslabel";
            Repairslabel.Size = new Size(189, 62);
            Repairslabel.TabIndex = 0;
            Repairslabel.Text = "Repairs";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(207, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(108, 108);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // AddRepairbuttonTop
            // 
            AddRepairbuttonTop.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AddRepairbuttonTop.Location = new Point(73, 169);
            AddRepairbuttonTop.Name = "AddRepairbuttonTop";
            AddRepairbuttonTop.Size = new Size(242, 57);
            AddRepairbuttonTop.TabIndex = 2;
            AddRepairbuttonTop.Text = "Add repair";
            AddRepairbuttonTop.UseVisualStyleBackColor = true;
            AddRepairbuttonTop.Click += AddRepairbuttonTop_Click;
            // 
            // RepairDateIn
            // 
            RepairDateIn.AutoSize = true;
            RepairDateIn.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RepairDateIn.Location = new Point(25, 244);
            RepairDateIn.Name = "RepairDateIn";
            RepairDateIn.Size = new Size(176, 23);
            RepairDateIn.TabIndex = 3;
            RepairDateIn.Text = "Enter repair date in: ";
            // 
            // RepairDateIntextBox
            // 
            RepairDateIntextBox.Location = new Point(194, 243);
            RepairDateIntextBox.Name = "RepairDateIntextBox";
            RepairDateIntextBox.Size = new Size(165, 27);
            RepairDateIntextBox.TabIndex = 4;
            // 
            // RepairDateOut
            // 
            RepairDateOut.AutoSize = true;
            RepairDateOut.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RepairDateOut.Location = new Point(25, 277);
            RepairDateOut.Name = "RepairDateOut";
            RepairDateOut.Size = new Size(183, 23);
            RepairDateOut.TabIndex = 5;
            RepairDateOut.Text = "Enter repair date out:";
            // 
            // RepairDateOuttextBox
            // 
            RepairDateOuttextBox.Location = new Point(207, 276);
            RepairDateOuttextBox.Name = "RepairDateOuttextBox";
            RepairDateOuttextBox.Size = new Size(165, 27);
            RepairDateOuttextBox.TabIndex = 6;
            // 
            // RepairTotalCost
            // 
            RepairTotalCost.AutoSize = true;
            RepairTotalCost.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RepairTotalCost.Location = new Point(25, 311);
            RepairTotalCost.Name = "RepairTotalCost";
            RepairTotalCost.Size = new Size(190, 23);
            RepairTotalCost.TabIndex = 7;
            RepairTotalCost.Text = "Enter repair total cost:";
            RepairTotalCost.Click += RepairTotalCost_Click;
            // 
            // RepairTotalCosttextBox
            // 
            RepairTotalCosttextBox.Location = new Point(214, 310);
            RepairTotalCosttextBox.Name = "RepairTotalCosttextBox";
            RepairTotalCosttextBox.Size = new Size(164, 27);
            RepairTotalCosttextBox.TabIndex = 8;
            RepairTotalCosttextBox.TextChanged += textBox1_TextChanged;
            // 
            // RepairType
            // 
            RepairType.AutoSize = true;
            RepairType.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RepairType.Location = new Point(25, 345);
            RepairType.Name = "RepairType";
            RepairType.Size = new Size(151, 23);
            RepairType.TabIndex = 9;
            RepairType.Text = "Enter repair type:";
            // 
            // RepairTypetextBox
            // 
            RepairTypetextBox.Location = new Point(173, 344);
            RepairTypetextBox.Name = "RepairTypetextBox";
            RepairTypetextBox.Size = new Size(171, 27);
            RepairTypetextBox.TabIndex = 10;
            // 
            // RepairVehicleId
            // 
            RepairVehicleId.AutoSize = true;
            RepairVehicleId.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RepairVehicleId.Location = new Point(24, 378);
            RepairVehicleId.Name = "RepairVehicleId";
            RepairVehicleId.Size = new Size(191, 23);
            RepairVehicleId.TabIndex = 11;
            RepairVehicleId.Text = "Enter repair vehicle id:";
            // 
            // RepairVehileIdtextBox
            // 
            RepairVehileIdtextBox.Location = new Point(214, 377);
            RepairVehileIdtextBox.Name = "RepairVehileIdtextBox";
            RepairVehileIdtextBox.Size = new Size(145, 27);
            RepairVehileIdtextBox.TabIndex = 12;
            // 
            // AddRepairButton
            // 
            AddRepairButton.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AddRepairButton.Location = new Point(342, 420);
            AddRepairButton.Name = "AddRepairButton";
            AddRepairButton.Size = new Size(148, 61);
            AddRepairButton.TabIndex = 13;
            AddRepairButton.Text = "Add";
            AddRepairButton.UseVisualStyleBackColor = true;
            AddRepairButton.Click += AddRepairButton_Click;
            // 
            // ViewAllRepairs
            // 
            ViewAllRepairs.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllRepairs.Location = new Point(680, 497);
            ViewAllRepairs.Name = "ViewAllRepairs";
            ViewAllRepairs.Size = new Size(290, 68);
            ViewAllRepairs.TabIndex = 14;
            ViewAllRepairs.Text = "View all repairs";
            ViewAllRepairs.UseVisualStyleBackColor = true;
            ViewAllRepairs.Click += ViewAllRepairs_Click;
            // 
            // ViewAllRepairslistBox
            // 
            ViewAllRepairslistBox.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllRepairslistBox.FormattingEnabled = true;
            ViewAllRepairslistBox.Location = new Point(505, 588);
            ViewAllRepairslistBox.Name = "ViewAllRepairslistBox";
            ViewAllRepairslistBox.Size = new Size(639, 344);
            ViewAllRepairslistBox.TabIndex = 15;
            ViewAllRepairslistBox.SelectedIndexChanged += ViewAllRepairslistBox_SelectedIndexChanged;
            // 
            // ViewAllRepairsForVehicle
            // 
            ViewAllRepairsForVehicle.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllRepairsForVehicle.Location = new Point(1256, 45);
            ViewAllRepairsForVehicle.Name = "ViewAllRepairsForVehicle";
            ViewAllRepairsForVehicle.Size = new Size(287, 75);
            ViewAllRepairsForVehicle.TabIndex = 16;
            ViewAllRepairsForVehicle.Text = "View all repairs for vehicle";
            ViewAllRepairsForVehicle.UseVisualStyleBackColor = true;
            ViewAllRepairsForVehicle.Click += ViewAllRepairsForVehicle_Click;
            // 
            // VehicleIdForSearch
            // 
            VehicleIdForSearch.AutoSize = true;
            VehicleIdForSearch.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            VehicleIdForSearch.Location = new Point(1333, 133);
            VehicleIdForSearch.Name = "VehicleIdForSearch";
            VehicleIdForSearch.Size = new Size(138, 23);
            VehicleIdForSearch.TabIndex = 17;
            VehicleIdForSearch.Text = "Enter vehicle id:";
            // 
            // VehicleIdForSeachtextBox
            // 
            VehicleIdForSeachtextBox.Location = new Point(1303, 159);
            VehicleIdForSeachtextBox.Name = "VehicleIdForSeachtextBox";
            VehicleIdForSeachtextBox.Size = new Size(197, 27);
            VehicleIdForSeachtextBox.TabIndex = 18;
            // 
            // RepairVehiclelistBox
            // 
            RepairVehiclelistBox.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RepairVehiclelistBox.FormattingEnabled = true;
            RepairVehiclelistBox.Location = new Point(1231, 203);
            RepairVehiclelistBox.Name = "RepairVehiclelistBox";
            RepairVehiclelistBox.Size = new Size(350, 64);
            RepairVehiclelistBox.TabIndex = 20;
            // 
            // ViewRepairsbutton
            // 
            ViewRepairsbutton.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewRepairsbutton.Location = new Point(1517, 274);
            ViewRepairsbutton.Name = "ViewRepairsbutton";
            ViewRepairsbutton.Size = new Size(164, 60);
            ViewRepairsbutton.TabIndex = 21;
            ViewRepairsbutton.Text = "View repairs";
            ViewRepairsbutton.UseVisualStyleBackColor = true;
            ViewRepairsbutton.Click += ViewRepairsbutton_Click;
            // 
            // ViewTotalCostbutton
            // 
            ViewTotalCostbutton.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewTotalCostbutton.Location = new Point(1333, 420);
            ViewTotalCostbutton.Name = "ViewTotalCostbutton";
            ViewTotalCostbutton.Size = new Size(320, 80);
            ViewTotalCostbutton.TabIndex = 22;
            ViewTotalCostbutton.Text = "View total cost of repairs for a client";
            ViewTotalCostbutton.UseVisualStyleBackColor = true;
            ViewTotalCostbutton.Click += ViewTotalCostbutton_Click;
            // 
            // ClientId
            // 
            ClientId.AutoSize = true;
            ClientId.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ClientId.Location = new Point(1426, 522);
            ClientId.Name = "ClientId";
            ClientId.Size = new Size(127, 23);
            ClientId.TabIndex = 23;
            ClientId.Text = "Enter client id:";
            // 
            // ClientIdForSearchtextBox
            // 
            ClientIdForSearchtextBox.Location = new Point(1387, 548);
            ClientIdForSearchtextBox.Name = "ClientIdForSearchtextBox";
            ClientIdForSearchtextBox.Size = new Size(217, 27);
            ClientIdForSearchtextBox.TabIndex = 24;
            // 
            // TotalCostlistBox
            // 
            TotalCostlistBox.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TotalCostlistBox.FormattingEnabled = true;
            TotalCostlistBox.Location = new Point(1323, 590);
            TotalCostlistBox.Name = "TotalCostlistBox";
            TotalCostlistBox.Size = new Size(358, 44);
            TotalCostlistBox.TabIndex = 25;
            // 
            // TotalCostbutton
            // 
            TotalCostbutton.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TotalCostbutton.Location = new Point(1675, 653);
            TotalCostbutton.Name = "TotalCostbutton";
            TotalCostbutton.Size = new Size(147, 53);
            TotalCostbutton.TabIndex = 26;
            TotalCostbutton.Text = "Total cost";
            TotalCostbutton.UseVisualStyleBackColor = true;
            TotalCostbutton.Click += TotalCostbutton_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(675, 80);
            button2.Name = "button2";
            button2.Size = new Size(295, 76);
            button2.TabIndex = 28;
            button2.Text = "View total cost of repairs for year";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // EnterYear
            // 
            EnterYear.AutoSize = true;
            EnterYear.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            EnterYear.Location = new Point(778, 162);
            EnterYear.Name = "EnterYear";
            EnterYear.Size = new Size(89, 20);
            EnterYear.TabIndex = 29;
            EnterYear.Text = "Enter year: ";
            // 
            // YeartextBox
            // 
            YeartextBox.Location = new Point(691, 187);
            YeartextBox.Name = "YeartextBox";
            YeartextBox.Size = new Size(269, 27);
            YeartextBox.TabIndex = 30;
            // 
            // TotalCostYearlistBox
            // 
            TotalCostYearlistBox.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TotalCostYearlistBox.FormattingEnabled = true;
            TotalCostYearlistBox.Location = new Point(660, 231);
            TotalCostYearlistBox.Name = "TotalCostYearlistBox";
            TotalCostYearlistBox.Size = new Size(354, 44);
            TotalCostYearlistBox.TabIndex = 31;
            // 
            // TotalCostForYearbutton
            // 
            TotalCostForYearbutton.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TotalCostForYearbutton.Location = new Point(959, 283);
            TotalCostForYearbutton.Name = "TotalCostForYearbutton";
            TotalCostForYearbutton.Size = new Size(172, 43);
            TotalCostForYearbutton.TabIndex = 32;
            TotalCostForYearbutton.Text = "Total cost";
            TotalCostForYearbutton.UseVisualStyleBackColor = true;
            TotalCostForYearbutton.Click += TotalCostForYearbutton_Click;
            // 
            // ExitRepairsbutton
            // 
            ExitRepairsbutton.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ExitRepairsbutton.Location = new Point(12, 950);
            ExitRepairsbutton.Name = "ExitRepairsbutton";
            ExitRepairsbutton.Size = new Size(194, 77);
            ExitRepairsbutton.TabIndex = 33;
            ExitRepairsbutton.Text = "Exit";
            ExitRepairsbutton.UseVisualStyleBackColor = true;
            ExitRepairsbutton.Click += ExitRepairsbutton_Click;
            // 
            // RepairForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1902, 1033);
            Controls.Add(ExitRepairsbutton);
            Controls.Add(TotalCostForYearbutton);
            Controls.Add(TotalCostYearlistBox);
            Controls.Add(YeartextBox);
            Controls.Add(EnterYear);
            Controls.Add(button2);
            Controls.Add(TotalCostbutton);
            Controls.Add(TotalCostlistBox);
            Controls.Add(ClientIdForSearchtextBox);
            Controls.Add(ClientId);
            Controls.Add(ViewTotalCostbutton);
            Controls.Add(ViewRepairsbutton);
            Controls.Add(RepairVehiclelistBox);
            Controls.Add(VehicleIdForSeachtextBox);
            Controls.Add(VehicleIdForSearch);
            Controls.Add(ViewAllRepairsForVehicle);
            Controls.Add(ViewAllRepairslistBox);
            Controls.Add(ViewAllRepairs);
            Controls.Add(AddRepairButton);
            Controls.Add(RepairVehileIdtextBox);
            Controls.Add(RepairVehicleId);
            Controls.Add(RepairTypetextBox);
            Controls.Add(RepairType);
            Controls.Add(RepairTotalCosttextBox);
            Controls.Add(RepairTotalCost);
            Controls.Add(RepairDateOuttextBox);
            Controls.Add(RepairDateOut);
            Controls.Add(RepairDateIntextBox);
            Controls.Add(RepairDateIn);
            Controls.Add(AddRepairbuttonTop);
            Controls.Add(pictureBox1);
            Controls.Add(Repairslabel);
            Name = "RepairForm";
            Text = "RepairForm";
            Load += RepairForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Repairslabel;
        private PictureBox pictureBox1;
        private Button AddRepairbuttonTop;
        private Label RepairDateIn;
        private TextBox RepairDateIntextBox;
        private Label RepairDateOut;
        private TextBox RepairDateOuttextBox;
        private Label RepairTotalCost;
        private TextBox RepairTotalCosttextBox;
        private Label RepairType;
        private TextBox RepairTypetextBox;
        private Label RepairVehicleId;
        private TextBox RepairVehileIdtextBox;
        private Button AddRepairButton;
        private Button ViewAllRepairs;
        private ListBox ViewAllRepairslistBox;
        private Button ViewAllRepairsForVehicle;
        private Label VehicleIdForSearch;
        private TextBox VehicleIdForSeachtextBox;
        private ListBox RepairVehiclelistBox;
        private Button ViewRepairsbutton;
        private Button ViewTotalCostbutton;
        private Label ClientId;
        private TextBox ClientIdForSearchtextBox;
        private ListBox TotalCostlistBox;
        private Button TotalCostbutton;
        private Button button2;
        private Label EnterYear;
        private TextBox YeartextBox;
        private ListBox TotalCostYearlistBox;
        private Button TotalCostForYearbutton;
        private Button ExitRepairsbutton;
    }
}