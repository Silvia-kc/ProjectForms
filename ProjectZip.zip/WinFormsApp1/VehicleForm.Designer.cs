﻿namespace WinFormsApp1
{
    partial class VehicleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VehicleForm));
            Vehiclelabel = new Label();
            pictureBox1 = new PictureBox();
            AddVehiclebuttonTop = new Button();
            VehicleBrand = new Label();
            VehicleBrandtextBox = new TextBox();
            VehicleModel = new Label();
            VehicleModeltextBox = new TextBox();
            VehicleYearOfManifacture = new Label();
            VehicleYearOfManifacturetextBox = new TextBox();
            VehicleLicensePlate = new Label();
            VehicleLicensePlatetextBox = new TextBox();
            AddVehiclebutton = new Button();
            VehicleClientId = new Label();
            VehicleClientIdtextBox = new TextBox();
            ViewAllVehicles = new Button();
            ViewAllVehicleslistBox = new ListBox();
            ViewAllVehiclesAboutClient = new Button();
            ClientIdForSearch = new Label();
            ClientIdForSearchtextBox = new TextBox();
            VehicleClientslistBox = new ListBox();
            ViewVehicles = new Button();
            MostVisitedCarBrand = new Button();
            MostVisitedCarBrandlistBox = new ListBox();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Vehiclelabel
            // 
            Vehiclelabel.AutoSize = true;
            Vehiclelabel.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Vehiclelabel.Location = new Point(12, 27);
            Vehiclelabel.Name = "Vehiclelabel";
            Vehiclelabel.Size = new Size(203, 62);
            Vehiclelabel.TabIndex = 0;
            Vehiclelabel.Text = "Vehicles";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(221, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(108, 112);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // AddVehiclebuttonTop
            // 
            AddVehiclebuttonTop.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AddVehiclebuttonTop.Location = new Point(71, 172);
            AddVehiclebuttonTop.Name = "AddVehiclebuttonTop";
            AddVehiclebuttonTop.Size = new Size(272, 54);
            AddVehiclebuttonTop.TabIndex = 2;
            AddVehiclebuttonTop.Text = "Add vehicle";
            AddVehiclebuttonTop.UseVisualStyleBackColor = true;
            AddVehiclebuttonTop.Click += AddVehiclebuttonTop_Click;
            // 
            // VehicleBrand
            // 
            VehicleBrand.AutoSize = true;
            VehicleBrand.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            VehicleBrand.Location = new Point(23, 244);
            VehicleBrand.Name = "VehicleBrand";
            VehicleBrand.Size = new Size(175, 23);
            VehicleBrand.TabIndex = 3;
            VehicleBrand.Text = "Enter vehicle brand: ";
            // 
            // VehicleBrandtextBox
            // 
            VehicleBrandtextBox.Location = new Point(193, 244);
            VehicleBrandtextBox.Name = "VehicleBrandtextBox";
            VehicleBrandtextBox.Size = new Size(183, 27);
            VehicleBrandtextBox.TabIndex = 4;
            // 
            // VehicleModel
            // 
            VehicleModel.AutoSize = true;
            VehicleModel.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            VehicleModel.Location = new Point(23, 284);
            VehicleModel.Name = "VehicleModel";
            VehicleModel.Size = new Size(173, 23);
            VehicleModel.TabIndex = 5;
            VehicleModel.Text = "Enter vehicle model:";
            // 
            // VehicleModeltextBox
            // 
            VehicleModeltextBox.Location = new Point(193, 283);
            VehicleModeltextBox.Name = "VehicleModeltextBox";
            VehicleModeltextBox.Size = new Size(183, 27);
            VehicleModeltextBox.TabIndex = 6;
            // 
            // VehicleYearOfManifacture
            // 
            VehicleYearOfManifacture.AutoSize = true;
            VehicleYearOfManifacture.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            VehicleYearOfManifacture.Location = new Point(23, 322);
            VehicleYearOfManifacture.Name = "VehicleYearOfManifacture";
            VehicleYearOfManifacture.Size = new Size(285, 23);
            VehicleYearOfManifacture.TabIndex = 7;
            VehicleYearOfManifacture.Text = "Enter vehicle year of manifacture: ";
            // 
            // VehicleYearOfManifacturetextBox
            // 
            VehicleYearOfManifacturetextBox.Location = new Point(301, 321);
            VehicleYearOfManifacturetextBox.Name = "VehicleYearOfManifacturetextBox";
            VehicleYearOfManifacturetextBox.Size = new Size(183, 27);
            VehicleYearOfManifacturetextBox.TabIndex = 8;
            // 
            // VehicleLicensePlate
            // 
            VehicleLicensePlate.AutoSize = true;
            VehicleLicensePlate.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            VehicleLicensePlate.Location = new Point(23, 358);
            VehicleLicensePlate.Name = "VehicleLicensePlate";
            VehicleLicensePlate.Size = new Size(221, 23);
            VehicleLicensePlate.TabIndex = 9;
            VehicleLicensePlate.Text = "Enter vehicle license plate:";
            // 
            // VehicleLicensePlatetextBox
            // 
            VehicleLicensePlatetextBox.Location = new Point(240, 358);
            VehicleLicensePlatetextBox.Name = "VehicleLicensePlatetextBox";
            VehicleLicensePlatetextBox.Size = new Size(183, 27);
            VehicleLicensePlatetextBox.TabIndex = 10;
            // 
            // AddVehiclebutton
            // 
            AddVehiclebutton.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AddVehiclebutton.Location = new Point(371, 436);
            AddVehiclebutton.Name = "AddVehiclebutton";
            AddVehiclebutton.Size = new Size(184, 69);
            AddVehiclebutton.TabIndex = 11;
            AddVehiclebutton.Text = "Add";
            AddVehiclebutton.UseVisualStyleBackColor = true;
            AddVehiclebutton.Click += AddVehiclebutton_Click;
            // 
            // VehicleClientId
            // 
            VehicleClientId.AutoSize = true;
            VehicleClientId.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            VehicleClientId.Location = new Point(23, 391);
            VehicleClientId.Name = "VehicleClientId";
            VehicleClientId.Size = new Size(187, 23);
            VehicleClientId.TabIndex = 12;
            VehicleClientId.Text = "Enter vehicle client id:";
            // 
            // VehicleClientIdtextBox
            // 
            VehicleClientIdtextBox.Location = new Point(205, 391);
            VehicleClientIdtextBox.Name = "VehicleClientIdtextBox";
            VehicleClientIdtextBox.Size = new Size(171, 27);
            VehicleClientIdtextBox.TabIndex = 13;
            // 
            // ViewAllVehicles
            // 
            ViewAllVehicles.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllVehicles.Location = new Point(785, 523);
            ViewAllVehicles.Name = "ViewAllVehicles";
            ViewAllVehicles.Size = new Size(271, 72);
            ViewAllVehicles.TabIndex = 14;
            ViewAllVehicles.Text = "View all vehicles";
            ViewAllVehicles.UseVisualStyleBackColor = true;
            ViewAllVehicles.Click += ViewAllVehicles_Click;
            // 
            // ViewAllVehicleslistBox
            // 
            ViewAllVehicleslistBox.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllVehicleslistBox.FormattingEnabled = true;
            ViewAllVehicleslistBox.Location = new Point(549, 615);
            ViewAllVehicleslistBox.Name = "ViewAllVehicleslistBox";
            ViewAllVehicleslistBox.Size = new Size(771, 304);
            ViewAllVehicleslistBox.TabIndex = 15;
            // 
            // ViewAllVehiclesAboutClient
            // 
            ViewAllVehiclesAboutClient.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllVehiclesAboutClient.Location = new Point(1051, 64);
            ViewAllVehiclesAboutClient.Name = "ViewAllVehiclesAboutClient";
            ViewAllVehiclesAboutClient.Size = new Size(366, 85);
            ViewAllVehiclesAboutClient.TabIndex = 16;
            ViewAllVehiclesAboutClient.Text = "View all vehicles about client";
            ViewAllVehiclesAboutClient.UseVisualStyleBackColor = true;
            ViewAllVehiclesAboutClient.Click += ViewAllVehiclesAboutClient_Click;
            // 
            // ClientIdForSearch
            // 
            ClientIdForSearch.AutoSize = true;
            ClientIdForSearch.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ClientIdForSearch.Location = new Point(1163, 161);
            ClientIdForSearch.Name = "ClientIdForSearch";
            ClientIdForSearch.Size = new Size(132, 23);
            ClientIdForSearch.TabIndex = 17;
            ClientIdForSearch.Text = "Enter client id: ";
            // 
            // ClientIdForSearchtextBox
            // 
            ClientIdForSearchtextBox.Location = new Point(1087, 189);
            ClientIdForSearchtextBox.Name = "ClientIdForSearchtextBox";
            ClientIdForSearchtextBox.Size = new Size(278, 27);
            ClientIdForSearchtextBox.TabIndex = 18;
            // 
            // VehicleClientslistBox
            // 
            VehicleClientslistBox.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            VehicleClientslistBox.FormattingEnabled = true;
            VehicleClientslistBox.Location = new Point(1005, 226);
            VehicleClientslistBox.Name = "VehicleClientslistBox";
            VehicleClientslistBox.Size = new Size(463, 84);
            VehicleClientslistBox.TabIndex = 19;
            // 
            // ViewVehicles
            // 
            ViewVehicles.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewVehicles.Location = new Point(1384, 316);
            ViewVehicles.Name = "ViewVehicles";
            ViewVehicles.Size = new Size(180, 61);
            ViewVehicles.TabIndex = 21;
            ViewVehicles.Text = "View vehicles";
            ViewVehicles.UseVisualStyleBackColor = true;
            ViewVehicles.Click += ViewVehicles_Click;
            // 
            // MostVisitedCarBrand
            // 
            MostVisitedCarBrand.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            MostVisitedCarBrand.Location = new Point(1463, 460);
            MostVisitedCarBrand.Name = "MostVisitedCarBrand";
            MostVisitedCarBrand.Size = new Size(375, 76);
            MostVisitedCarBrand.TabIndex = 22;
            MostVisitedCarBrand.Text = "View car brand that visits the service the most ";
            MostVisitedCarBrand.UseVisualStyleBackColor = true;
            MostVisitedCarBrand.Click += MostVisitedCarBrand_Click;
            // 
            // MostVisitedCarBrandlistBox
            // 
            MostVisitedCarBrandlistBox.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            MostVisitedCarBrandlistBox.FormattingEnabled = true;
            MostVisitedCarBrandlistBox.Location = new Point(1438, 553);
            MostVisitedCarBrandlistBox.Name = "MostVisitedCarBrandlistBox";
            MostVisitedCarBrandlistBox.Size = new Size(428, 24);
            MostVisitedCarBrandlistBox.TabIndex = 23;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(12, 950);
            button1.Name = "button1";
            button1.Size = new Size(194, 77);
            button1.TabIndex = 24;
            button1.Text = "Exit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // VehicleForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1902, 1033);
            Controls.Add(button1);
            Controls.Add(MostVisitedCarBrandlistBox);
            Controls.Add(MostVisitedCarBrand);
            Controls.Add(ViewVehicles);
            Controls.Add(VehicleClientslistBox);
            Controls.Add(ClientIdForSearchtextBox);
            Controls.Add(ClientIdForSearch);
            Controls.Add(ViewAllVehiclesAboutClient);
            Controls.Add(ViewAllVehicleslistBox);
            Controls.Add(ViewAllVehicles);
            Controls.Add(VehicleClientIdtextBox);
            Controls.Add(VehicleClientId);
            Controls.Add(AddVehiclebutton);
            Controls.Add(VehicleLicensePlatetextBox);
            Controls.Add(VehicleLicensePlate);
            Controls.Add(VehicleYearOfManifacturetextBox);
            Controls.Add(VehicleYearOfManifacture);
            Controls.Add(VehicleModeltextBox);
            Controls.Add(VehicleModel);
            Controls.Add(VehicleBrandtextBox);
            Controls.Add(VehicleBrand);
            Controls.Add(AddVehiclebuttonTop);
            Controls.Add(pictureBox1);
            Controls.Add(Vehiclelabel);
            Name = "VehicleForm";
            Text = "VehicleForm";
            Load += VehicleForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Vehiclelabel;
        private PictureBox pictureBox1;
        private Button AddVehiclebuttonTop;
        private Label VehicleBrand;
        private TextBox VehicleBrandtextBox;
        private Label VehicleModel;
        private TextBox VehicleModeltextBox;
        private Label VehicleYearOfManifacture;
        private TextBox VehicleYearOfManifacturetextBox;
        private Label VehicleLicensePlate;
        private TextBox VehicleLicensePlatetextBox;
        private Button AddVehiclebutton;
        private Label VehicleClientId;
        private TextBox VehicleClientIdtextBox;
        private Button ViewAllVehicles;
        private ListBox ViewAllVehicleslistBox;
        private Button ViewAllVehiclesAboutClient;
        private Label ClientIdForSearch;
        private TextBox ClientIdForSearchtextBox;
        private ListBox VehicleClientslistBox;
        private Button ViewVehicles;
        private Button MostVisitedCarBrand;
        private ListBox MostVisitedCarBrandlistBox;
        private Button button1;
    }
}