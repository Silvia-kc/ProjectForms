﻿namespace WinFormsApp1
{
    partial class PartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PartForm));
            Partlabel = new Label();
            AddPartbuttonTop = new Button();
            PartName = new Label();
            PartNametextBox = new TextBox();
            PartPrice = new Label();
            PartPricetextBox = new TextBox();
            AddPartButton = new Button();
            ViewAllParts = new Button();
            ViewAllPartslistBox = new ListBox();
            ViewMostCommonlyUsedPart = new Button();
            sqlCommand1 = new Microsoft.Data.SqlClient.SqlCommand();
            ViewMostCmmonlyUsedPartlistBox = new ListBox();
            pictureBox1 = new PictureBox();
            ExitPartsbutton = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // Partlabel
            // 
            Partlabel.AutoSize = true;
            Partlabel.Font = new Font("Segoe UI", 28.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Partlabel.Location = new Point(23, 32);
            Partlabel.Name = "Partlabel";
            Partlabel.Size = new Size(139, 62);
            Partlabel.TabIndex = 0;
            Partlabel.Text = "Parts";
            // 
            // AddPartbuttonTop
            // 
            AddPartbuttonTop.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AddPartbuttonTop.Location = new Point(89, 172);
            AddPartbuttonTop.Name = "AddPartbuttonTop";
            AddPartbuttonTop.Size = new Size(232, 53);
            AddPartbuttonTop.TabIndex = 2;
            AddPartbuttonTop.Text = "Add part";
            AddPartbuttonTop.UseVisualStyleBackColor = true;
            AddPartbuttonTop.Click += AddPartbuttonTop_Click;
            // 
            // PartName
            // 
            PartName.AutoSize = true;
            PartName.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PartName.Location = new Point(23, 260);
            PartName.Name = "PartName";
            PartName.Size = new Size(150, 23);
            PartName.TabIndex = 3;
            PartName.Text = "Enter part name: ";
            // 
            // PartNametextBox
            // 
            PartNametextBox.Location = new Point(170, 260);
            PartNametextBox.Name = "PartNametextBox";
            PartNametextBox.Size = new Size(190, 27);
            PartNametextBox.TabIndex = 4;
            // 
            // PartPrice
            // 
            PartPrice.AutoSize = true;
            PartPrice.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            PartPrice.Location = new Point(23, 306);
            PartPrice.Name = "PartPrice";
            PartPrice.Size = new Size(146, 23);
            PartPrice.TabIndex = 5;
            PartPrice.Text = "Enter part price: ";
            // 
            // PartPricetextBox
            // 
            PartPricetextBox.Location = new Point(170, 302);
            PartPricetextBox.Name = "PartPricetextBox";
            PartPricetextBox.Size = new Size(190, 27);
            PartPricetextBox.TabIndex = 6;
            // 
            // AddPartButton
            // 
            AddPartButton.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AddPartButton.Location = new Point(310, 351);
            AddPartButton.Name = "AddPartButton";
            AddPartButton.Size = new Size(200, 64);
            AddPartButton.TabIndex = 7;
            AddPartButton.Text = "Add";
            AddPartButton.UseVisualStyleBackColor = true;
            AddPartButton.Click += AddPartButton_Click;
            // 
            // ViewAllParts
            // 
            ViewAllParts.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllParts.Location = new Point(803, 407);
            ViewAllParts.Name = "ViewAllParts";
            ViewAllParts.Size = new Size(292, 64);
            ViewAllParts.TabIndex = 8;
            ViewAllParts.Text = "View all parts";
            ViewAllParts.UseVisualStyleBackColor = true;
            ViewAllParts.Click += ViewAllParts_Click;
            // 
            // ViewAllPartslistBox
            // 
            ViewAllPartslistBox.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewAllPartslistBox.FormattingEnabled = true;
            ViewAllPartslistBox.Location = new Point(803, 520);
            ViewAllPartslistBox.Name = "ViewAllPartslistBox";
            ViewAllPartslistBox.Size = new Size(292, 324);
            ViewAllPartslistBox.TabIndex = 9;
            // 
            // ViewMostCommonlyUsedPart
            // 
            ViewMostCommonlyUsedPart.Font = new Font("Segoe UI", 13.2000008F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewMostCommonlyUsedPart.Location = new Point(1336, 186);
            ViewMostCommonlyUsedPart.Name = "ViewMostCommonlyUsedPart";
            ViewMostCommonlyUsedPart.Size = new Size(416, 74);
            ViewMostCommonlyUsedPart.TabIndex = 11;
            ViewMostCommonlyUsedPart.Text = "View most commonly used part";
            ViewMostCommonlyUsedPart.UseVisualStyleBackColor = true;
            ViewMostCommonlyUsedPart.Click += ViewMostCommonlyUsedPart_Click;
            // 
            // sqlCommand1
            // 
            sqlCommand1.CommandTimeout = 30;
            sqlCommand1.EnableOptimizedParameterBinding = false;
            // 
            // ViewMostCmmonlyUsedPartlistBox
            // 
            ViewMostCmmonlyUsedPartlistBox.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ViewMostCmmonlyUsedPartlistBox.FormattingEnabled = true;
            ViewMostCmmonlyUsedPartlistBox.Location = new Point(1301, 276);
            ViewMostCmmonlyUsedPartlistBox.Name = "ViewMostCmmonlyUsedPartlistBox";
            ViewMostCmmonlyUsedPartlistBox.Size = new Size(511, 24);
            ViewMostCmmonlyUsedPartlistBox.TabIndex = 12;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(168, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(121, 120);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 13;
            pictureBox1.TabStop = false;
            // 
            // ExitPartsbutton
            // 
            ExitPartsbutton.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ExitPartsbutton.Location = new Point(12, 950);
            ExitPartsbutton.Name = "ExitPartsbutton";
            ExitPartsbutton.Size = new Size(194, 71);
            ExitPartsbutton.TabIndex = 14;
            ExitPartsbutton.Text = "Exit";
            ExitPartsbutton.UseVisualStyleBackColor = true;
            ExitPartsbutton.Click += ExitPartsbutton_Click;
            // 
            // PartForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1902, 1033);
            Controls.Add(ExitPartsbutton);
            Controls.Add(pictureBox1);
            Controls.Add(ViewMostCmmonlyUsedPartlistBox);
            Controls.Add(ViewMostCommonlyUsedPart);
            Controls.Add(ViewAllPartslistBox);
            Controls.Add(ViewAllParts);
            Controls.Add(AddPartButton);
            Controls.Add(PartPricetextBox);
            Controls.Add(PartPrice);
            Controls.Add(PartNametextBox);
            Controls.Add(PartName);
            Controls.Add(AddPartbuttonTop);
            Controls.Add(Partlabel);
            Name = "PartForm";
            Text = "Parts";
            Load += Parts_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Partlabel;
        private Button AddPartbuttonTop;
        private Label PartName;
        private TextBox PartNametextBox;
        private Label PartPrice;
        private TextBox PartPricetextBox;
        private Button AddPartButton;
        private Button ViewAllParts;
        private ListBox ViewAllPartslistBox;
        private Button ViewMostCommonlyUsedPart;
        private Microsoft.Data.SqlClient.SqlCommand sqlCommand1;
        private ListBox ViewMostCmmonlyUsedPartlistBox;
        private PictureBox pictureBox1;
        private Button ExitPartsbutton;
    }
}