﻿using Data;
using Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class MechanicController
    {
        CarServiceDBContext context = new CarServiceDBContext();
        public async Task AddMechanic(string firstName, string lastName, string specialization )
        {
            Mechanics mechanic = new Mechanics()
            { 
                first_name = firstName,
                last_name = lastName,
                specialization = specialization,
            };
            context.Mechanics.Add(mechanic);
            await context.SaveChangesAsync();
        }
        public async Task<List<Mechanics>> GetAllMechanics()
        {
            var mechanics = await context.Mechanics.ToListAsync();
            return mechanics;
        }
        public async Task RemoveMechanicById(int id)
        {
            var mechanic = await context.Mechanics.FirstOrDefaultAsync(m=>m.mechanic_id == id);
            context.Mechanics.Remove(mechanic);
            await context.SaveChangesAsync();
        }
        public async Task UpdateMechanicFirstName(int id, string newFisrtName)
        {
            var mechanic = await context.Mechanics.FirstOrDefaultAsync(m=>m.mechanic_id == id);
            mechanic.first_name = newFisrtName;
            await context.SaveChangesAsync();
        }
        public async Task UpdateMechanicLastName(int id, string newLastName)
        {
            var mechanic = await context.Mechanics.FirstOrDefaultAsync(m=>m.mechanic_id == id);
            mechanic.last_name = newLastName;
            await context.SaveChangesAsync();
        }
        public async Task UpdateMechanicSpecialization(int id, string newSpecialization)
        {
            var mechanic = await context.Mechanics.FirstOrDefaultAsync(m=>m.mechanic_id == id);
            mechanic.specialization = newSpecialization;
            await context.SaveChangesAsync();
        }
        public async Task<Mechanics> BusiestMechanic()
        {
            var busiestMechanicId = await context.RepairMechanic.GroupBy(rm => rm.mechanic_id)
                                                                .OrderByDescending(g => g.Count())
                                                                .Select(g => g.Key)
                                                                .FirstOrDefaultAsync();

            var mechanic = await context.Mechanics.FirstOrDefaultAsync(m => m.mechanic_id == busiestMechanicId);
            return mechanic;
        }
    }
}
