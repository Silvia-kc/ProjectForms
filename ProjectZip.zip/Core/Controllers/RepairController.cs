﻿using Data;
using Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class RepairController
    {
        CarServiceDBContext context = new CarServiceDBContext();
        public async Task AddRepair(DateOnly dateIn, DateOnly dateOut, double toalCost, string type, int vehicleId)
        {
            Repairs repair = new Repairs()
            {
                date_in = dateIn,
                date_out = dateOut,
                total_cost = toalCost,
                repair_type = type,
                vehicle_id = vehicleId
            };
            context.Repairs.Add(repair);
            await context.SaveChangesAsync();   
        }
        public async Task<List<Repairs>> ViewAllReapirs()
        {
            var repairs = await context.Repairs.ToListAsync();
            return repairs;
        }
        public async Task RemoveReapirById(int id)
        {
            var repair = await context.Repairs.FirstOrDefaultAsync(r=>r.repair_id == id);
            context.Repairs.Remove(repair);
            await context.SaveChangesAsync();
        }
        public async Task UpdateRepairDateIn(int id, DateOnly newDateIn)
        {
            var repair = await context.Repairs.FirstOrDefaultAsync(r=>r.repair_id == id);
            repair.date_in = newDateIn;
            await context.SaveChangesAsync();
        }
        public async Task UpdateRepairDateOut(int id, DateOnly newDateOut )
        {
            var repair = await context.Repairs.FirstOrDefaultAsync(r => r.repair_id == id);
            repair.date_out = newDateOut;
            await context.SaveChangesAsync();
        }
        public async Task UpdateRepairTotalCost(int id, double newTotalCost)
        {
            var repair = await context.Repairs.FirstOrDefaultAsync(r => r.repair_id == id);
            repair.total_cost = newTotalCost;
            await context.SaveChangesAsync();
        }
        public async Task UpdateRepairType(int id, string newType)
        {
            var repair = await context.Repairs.FirstOrDefaultAsync(r=> r.repair_id == id);
            repair.repair_type = newType;
            await context.SaveChangesAsync();
        }
        public async Task UpdateRepairVehicleId(int id, int newVehicleId)
        {
            var repair = await context.Repairs.FirstOrDefaultAsync(r => r.repair_id == id);
            repair.vehicle_id = newVehicleId;
            await context.SaveChangesAsync();
        }
        public async Task<List<Repairs>> AllRepairsForVehcile(int vehicleId)
        {
            var repairs = await context.Repairs.Where(r=>r.vehicle_id == vehicleId)
                                               .ToListAsync();
            return repairs;
        }
       public async Task<double> TotalCostOfRepairsForClient(int clientId)
       {
            var totalCost = await context.Repairs.Where(r => r.vehicle.client_id == clientId)
                                         .SumAsync(r => r.total_cost);
            return totalCost;
        }
        public async Task<double> TotalCostOfRepairsForYear(int year)
        {
            var totalCost = await context.Repairs.Where(r => r.date_in.Year == year) 
                                                 .SumAsync(r => r.total_cost); 
            return totalCost;
        }
        
    }
}
