﻿using Data;
using Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class RepairMechanicController
    {
        CarServiceDBContext context = new CarServiceDBContext();
        public async Task AddRepairMechanic(int repairId, int mechanicId, int workingHours)
        {
            RepairMechanics repairMechanic = new RepairMechanics()
            { 
                repair_id = repairId,
                mechanic_id = mechanicId,
                working_hours = workingHours
            };
            context.RepairMechanic.Add(repairMechanic);
            await context.SaveChangesAsync();
        }
        public async Task<List<RepairMechanics>> ViewAllRepairMechanics()
        {
            var repairMechanics = await context.RepairMechanic.ToListAsync();
            return repairMechanics;
        }
        public async Task RemoveRepairMechanicById(int repairId, int mechanicId)
        {
            var repairMechanic = await context.RepairMechanic.FirstOrDefaultAsync(rm=>rm.repair_id == repairId && rm.mechanic_id == mechanicId);
            context.RepairMechanic.Remove(repairMechanic);
            await context.SaveChangesAsync();
        }
        public async Task UpdateRepairId(int repairId, int mechanicId, int newRepairId)
        {
            var repairMechanic = await context.RepairMechanic.FirstOrDefaultAsync(rm => rm.repair_id == repairId && rm.mechanic_id == mechanicId);
            repairMechanic.repair_id = newRepairId;
            await context.SaveChangesAsync();
        }
        public async Task UpdateMechanicId(int repairId, int mechanicId, int newMechanicId)
        {
            var repairMechanic = await context.RepairMechanic.FirstOrDefaultAsync(rm => rm.repair_id == repairId && rm.mechanic_id == mechanicId);
            repairMechanic.mechanic_id = newMechanicId;
            await context.SaveChangesAsync();
        }
        public async Task UpdateWorkingHours(int repairId, int mechanicId, int newWorkingHours)
        {
            var repairMechanic = await context.RepairMechanic.FirstOrDefaultAsync(rm => rm.repair_id == repairId && rm.mechanic_id == mechanicId);
            repairMechanic.working_hours = newWorkingHours;     
            await context.SaveChangesAsync();
        }
        public async Task<List<Mechanics>> MechanicWorkedOnAGivenRepair(int repairId)
        {
            var mechanics = await context.RepairMechanic.Where(rm => rm.repair_id == repairId)
                                                        .Select(rm => rm.mechanics)
                                                        .ToListAsync();
            return mechanics;
        }
    }
}
