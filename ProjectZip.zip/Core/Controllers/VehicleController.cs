﻿using Data;
using Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class VehicleController
    {
        CarServiceDBContext context = new CarServiceDBContext();
        public async Task AddVehicle(string brand, string model, int yearOfmanifacture, string licensePlate, int clientid)
        {
            Vehicles vehicle = new Vehicles()
            { 
                brand = brand,
                model = model,
                year_of_manifacture = yearOfmanifacture,
                license_plate = licensePlate,
                client_id = clientid
            };
            context.Vehicles.Add(vehicle);
            await context.SaveChangesAsync();
        }
        public async Task<List<Vehicles>> ViewAllVehicles()
        {
            var vehicles = await context.Vehicles.Include(x=>x.repairs).ToListAsync();
            return vehicles;
        }
        public async Task RemoveVehicleById(int id)
        {
            var vehicle = await context.Vehicles.FirstOrDefaultAsync(v=>v.vehicle_id == id);    
            context.Vehicles.Remove(vehicle);
            await context.SaveChangesAsync();
        }
        public async Task UpdateVehicleBrand(int id, string newBrand)
        {
            var vehicle = await context.Vehicles.FirstOrDefaultAsync(v=>v.vehicle_id == id);
            vehicle.brand = newBrand;
            await context.SaveChangesAsync();
        }
        public async Task UpdateVehicleModel(int id, string model)
        {
            var vehicle = await context.Vehicles.FirstOrDefaultAsync(v=>v.vehicle_id == id);
            vehicle.model = model;
            await context.SaveChangesAsync();
        }
        public async Task UpdateVehicleYearOfManifacture(int id, int newYearOfManifacture)
        {
            var vehicle = await context.Vehicles.FirstOrDefaultAsync(v=>v.vehicle_id == id);
            vehicle.year_of_manifacture = newYearOfManifacture;
            await context.SaveChangesAsync();
        }
        public async Task UpdateVehicleLicensePlate(int id, string newLicensePlate)
        {
            var vehicle = await context.Vehicles.FirstOrDefaultAsync(v => v.vehicle_id == id);
            vehicle.license_plate = newLicensePlate;
            await context.SaveChangesAsync();
        }
        public async Task UpdateVehicleClientId(int id, int newClientId)
        {
            var vehicle = await context.Vehicles.FirstOrDefaultAsync(v => v.vehicle_id == id);
            vehicle.client_id = newClientId;
            await context.SaveChangesAsync();
        }
        public async Task<List<Vehicles>> AllClientVehicles(int clientId)
        {
            var vehicles = await context.Vehicles.Where(v => v.client_id == clientId)
                                                .ToListAsync();
            return vehicles;
        }
        public async Task<string> MostVisitedCarBrand()
        {
            var brand = await context.Vehicles.GroupBy(v => v.brand) 
                                                         .OrderByDescending(g => g.Count()) 
                                                         .Select(g => g.Key)
                                                         .FirstOrDefaultAsync(); 

            return brand;
        }
    }
}
