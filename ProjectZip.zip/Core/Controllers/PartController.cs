﻿using Data;
using Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class PartController
    {
        CarServiceDBContext context = new CarServiceDBContext();
        public async Task AddPart(string name, double price)
        {
            Parts part = new Parts()
            { 
                name = name,
                price = price
            };
            context.Parts.Add(part);
            await context.SaveChangesAsync();
        }
        public async Task<List<Parts>> GetAllParts()
        {
            var parts = await context.Parts.ToListAsync();
            return parts;
        }
        public async Task RemovePartById(int id)
        {
            var part = await context.Parts.FirstOrDefaultAsync(p=>p.part_id == id);
            context.Parts.Remove(part);
            await context.SaveChangesAsync();
        }
        public async Task UpdatePartName(int id, string newName)
        {
            var part = await context.Parts.FirstOrDefaultAsync(p=>p.part_id == id);
            part.name = newName;
            await context.SaveChangesAsync();
        }
        public async Task UpdatePartPrice(int id, double newPrice)
        {
            var part = await context.Parts.FirstOrDefaultAsync(p=>p.part_id == id);
            part.price = newPrice;
            await context.SaveChangesAsync();
        }
        public async Task<Parts> MostCommonlyUsedPart()
        {
            var part = await context.Parts.Include(p => p.repair_parts)
                                          .GroupBy(p => p.part_id)
                                          .OrderByDescending(p => p.Count())
                                          .Select(p => p.First())
                                          .FirstOrDefaultAsync();
             return part;
        }
    }
}
