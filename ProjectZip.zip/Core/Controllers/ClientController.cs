﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Data;
using Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Core
{
    public class ClientController
    {
        CarServiceDBContext context = new CarServiceDBContext();
        public async Task AddClient(string firstName, string lastName, string phoneNumber, string email)
        {
            Clients client = new Clients()
            {
                first_name = firstName,
                last_name = lastName,
                phone_number = phoneNumber,
                email = email
            };
            context.Clients.Add(client);
            await context.SaveChangesAsync();

        }
        public async Task<List<Clients>> GetAllClients()
        {
            var clients = await context.Clients.Include(x=>x.vehicles).ToListAsync();
            return clients;
        }
        public async Task RemoveClientById(int id)
        {
            var client = await context.Clients.FirstOrDefaultAsync(c=>c.client_Id == id);
            context.Clients.Remove(client);
            await context.SaveChangesAsync();   
        }
        public async Task UpdateClientFirstName(int id, string newFisrtName)
        {
            var client = await context.Clients.FirstOrDefaultAsync(c=> c.client_Id == id);
            client.first_name = newFisrtName;
            await context.SaveChangesAsync();
        }
        public async Task UpdateClientLastName(int id, string newLastName)
        {
            var client = await context.Clients.FirstOrDefaultAsync(c=>c.client_Id==id); 
            client.last_name = newLastName;
            await context.SaveChangesAsync();
        }
        public async Task UpdateClientPhoneNumber(int id, string newPhoneNumber)
        {
            var client = await context.Clients.FirstOrDefaultAsync(c => c.client_Id == id);
            client.phone_number = newPhoneNumber;
            await context.SaveChangesAsync();
        }
        public async Task UpdateClientEmail(int id, string newEmail)
        {
            var client = await context.Clients.FirstOrDefaultAsync(c => c.client_Id == id);
            client.email = newEmail;
            await context.SaveChangesAsync();
        }
        public async Task<Clients> SearchClientByFirstName(string firstName)
        {
            var client = await context.Clients.FirstOrDefaultAsync(c=>c.first_name == firstName);
            return client;
        }
    }
}
