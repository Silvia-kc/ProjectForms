﻿using Data;
using Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class RepairPartController
    {
        CarServiceDBContext context = new CarServiceDBContext();
        public async Task AddRepairPart(int repairId, int partId, int quantity)
        {
            RepairParts repairPart = new RepairParts()
            {
                repair_id = repairId,
                part_id = partId,
                quantity = quantity
            };
            context.RepairParts.Add(repairPart);
            await context.SaveChangesAsync();
        }
        public async Task<List<RepairParts>> ViewAllRepairParts()
        {
            var repairParts = await context.RepairParts.ToListAsync();
            return repairParts;
        }
        public async Task RemoveRepairPartById(int repairId, int partId)
        {
            var repairPart = await context.RepairParts.FirstOrDefaultAsync(rp => rp.repair_id == repairId && rp.part_id == partId);
            context.RepairParts.Remove(repairPart);
            await context.SaveChangesAsync();
        }
        public async Task UpdateRepairId(int repairId, int partId, int newRepairId)
        {
            var repairPart = await context.RepairParts.FirstOrDefaultAsync(rp => rp.repair_id == repairId && rp.part_id == partId);
            repairPart.repair_id = newRepairId;
            await context.SaveChangesAsync();
        }
        public async Task UpdatePartId(int repairId, int partId, int newPartId)
        {
            var repairPart = await context.RepairParts.FirstOrDefaultAsync(rp => rp.repair_id == repairId && rp.part_id == partId);
            repairPart.part_id = newPartId;
            await context.SaveChangesAsync();
        }
        public async Task UpdateQunatity(int repairId, int partId, int newQuantity)
        {
            var repairPart = await context.RepairParts.FirstOrDefaultAsync(rp => rp.repair_id == repairId && rp.part_id == partId);
            repairPart.quantity = newQuantity;
            await context.SaveChangesAsync();
        }
        public async Task<List<Repairs>> RepairsContainingGivenPart(string partName)
        {
            var repairs = await context.RepairParts.Where(rp => rp.parts.name == partName)
                                                   .Select(rp => rp.repairs)
                                                   .ToListAsync();
            return repairs;
        }
    }
}
