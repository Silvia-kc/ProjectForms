﻿using Data;
using Data.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class ImportFiles
    {
        private readonly CarServiceDBContext context;

        public ImportFiles(CarServiceDBContext context)
        {
            this.context = context;
        }
        public async Task Clients()
        {
            if (await context.Clients.AnyAsync()) return;

            var lines = await File.ReadAllLinesAsync("../../../../Core/Data/Clients.txt");
            foreach (var line in lines)
            {
                var parts = line.Split(',');
                var client = new Clients
                {
                    first_name = parts[0],
                    last_name = parts[1],
                    phone_number = parts[2],
                    email = parts[3]
                };
                context.Clients.Add(client);
            }
            await context.SaveChangesAsync();
        }
        public async Task Vehicles()
        {
            if (await context.Vehicles.AnyAsync()) return;

            var lines = await File.ReadAllLinesAsync("../../../../Core/Data/Vehicles.txt");
            foreach (var line in lines)
            {
                var parts = line.Split(',');
                var vehicle = new Vehicles
                {
                    brand = parts[0],
                    model = parts[1],
                    year_of_manifacture = int.Parse(parts[2]),
                    license_plate = parts[3],
                    client_id = int.Parse(parts[4]),
                };
                context.Vehicles.Add(vehicle);
            }
            await context.SaveChangesAsync();
        }
        public async Task Repairs()
        {
            if(await context.Repairs.AnyAsync()) return;

            var lines = await File.ReadAllLinesAsync("../../../../Core/Data/Repairs.txt");
            foreach(var line in lines)
            {
                var parts = line.Split(',');
                var repair = new Repairs
                {
                    date_in = DateOnly.Parse(parts[0]),
                    date_out = DateOnly.Parse(parts[1]),
                    total_cost = double.Parse(parts[2]),
                    repair_type = parts[3],
                    vehicle_id = int.Parse(parts[4])
                };
                context.Repairs.Add(repair);
            }
            await context.SaveChangesAsync();
        }
        public async Task Mechanics()
        {
            if (await context.Mechanics.AnyAsync()) return;

            var lines = await File.ReadAllLinesAsync("../../../../Core/Data/Mechanics.txt");
            foreach (var line in lines)
            {
                var parts = line.Split(',');
                var mechanic = new Mechanics
                {
                    first_name = parts[0],
                    last_name = parts[1],
                    specialization = parts[2]
                };
                context.Mechanics.Add(mechanic);
            }
            await context.SaveChangesAsync();
        }
        public async Task Parts()
        {
            if (await context.Parts.AnyAsync()) return;

            var lines = await File.ReadAllLinesAsync("../../../../Core/Data/Parts.txt");
            foreach (var line in lines)
            {
                var parts = line.Split(',');
                var part = new Parts
                {
                   name = parts[0],
                   price = double.Parse(parts[1])
                };
                context.Parts.Add(part);
            }
            await context.SaveChangesAsync();
        }
        public async Task RepairMechanics()
        {
            if (await context.RepairMechanic.AnyAsync()) return;

            var lines = await File.ReadAllLinesAsync("../../../../Core/Data/RepairMechanics.txt");
            foreach (var line in lines)
            {
                var parts = line.Split(',');
                var repairMechanic = new RepairMechanics
                {
                    repair_id = int.Parse(parts[0]),
                    mechanic_id = int.Parse(parts[1]),
                    working_hours = int.Parse(parts[2])
                };
                context.RepairMechanic.Add(repairMechanic);
            }
            await context.SaveChangesAsync();
        }
        public async Task RepairParts()
        {
            if (await context.RepairParts.AnyAsync()) return;

            var lines = await File.ReadAllLinesAsync("../../../../Core/Data/RepairParts.txt");
            foreach (var line in lines)
            {
                var parts = line.Split(',');
                var repairPart = new RepairParts
                {
                    repair_id = int.Parse(parts[0]),
                    part_id = int.Parse(parts[1]),
                    quantity = int.Parse(parts[2])
                };
                context.RepairParts.Add(repairPart);
            }
            await context.SaveChangesAsync();
        }
    }
}
