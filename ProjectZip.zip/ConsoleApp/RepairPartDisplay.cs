﻿using Core;
using Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class RepairPartDisplay
    {
        RepairPartController repairPartController = new RepairPartController();
        public async Task AddRepairPart()
        {
            Console.WriteLine("Enter repair id: ");
            int repairId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter part id: ");
            int partId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter quantity: ");
            int quantity = int.Parse(Console.ReadLine());
            await repairPartController.AddRepairPart(repairId, partId, quantity);
            Console.WriteLine("Addidng was successful!");
        }
        public async Task ViewAllRepairPart()
        {
            List<RepairParts> repairParts = await repairPartController.ViewAllRepairParts();
            foreach(var repairPart in repairParts)
            {
                Console.WriteLine($"Repair id: {repairPart.repair_id}. Part id: {repairPart.part_id}. Quantity - {repairPart.quantity}");
            }
        }
        public async Task RemoveRepairPartById()
        {
            Console.WriteLine("Enter repair id to remove: ");
            int repiarId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter part id to remove: ");
            int partId = int.Parse(Console.ReadLine());
            await repairPartController.RemoveRepairPartById(repiarId, partId);
            Console.WriteLine("Removal was successful!");
        }
        public async Task UpdateRepairId()
        {
            Console.WriteLine("Enter repair id for update: ");
            int repairId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter part id for update: ");
            int partId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter new repair id: ");
            int newId = int.Parse(Console.ReadLine());
            await repairPartController.UpdateRepairId(repairId, partId, newId);
            Console.WriteLine("Repair id was changed successfully!");
        }
        public async Task UpdatePartId()
        {
            Console.WriteLine("Enter repair id for update: ");
            int repairId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter part id for update: ");
            int partId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter new part id: ");
            int newId = int.Parse(Console.ReadLine());
            await repairPartController.UpdatePartId(repairId, partId, newId);
            Console.WriteLine("Part id was changed successfully!");
        }
        public async Task UpdateQuantity()
        {
            Console.WriteLine("Enter repair id for update: ");
            int repairId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter part id for update: ");
            int partId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter new quantity: ");
            int newQuantity = int.Parse(Console.ReadLine());
            await repairPartController.UpdateQunatity(repairId, partId, newQuantity);
            Console.WriteLine("Quantity was changed successfully!");
        }
        public async Task RepairsContainingGivenPart()
        {
            Console.WriteLine("Enter part name: ");
            string name = Console.ReadLine();
            List<Repairs> repairs = await repairPartController.RepairsContainingGivenPart(name);
            foreach(var repair in repairs)
            {
                Console.WriteLine($"Repair type: {repair.repair_type}. Cost {repair.total_cost} lv.");
            }
        }
        public async Task RepairPartMenu()
        {
            while(true)
            {
                Console.WriteLine("1.Add to repair part");
                Console.WriteLine("2.View all from repair part");
                Console.WriteLine("3.Remove from repair part by id");
                Console.WriteLine("4.Update from repair part: ");
                Console.WriteLine("5.View the repairs that containing a given part");
                Console.WriteLine("6.Exit");
                int num = int.Parse(Console.ReadLine());
                if(num == 6)
                {
                    break;
                }
                switch (num)
                {
                    case 1:
                        await AddRepairPart();
                        break;
                    case 2:
                        await ViewAllRepairPart();
                        break;
                    case 3:
                        await RemoveRepairPartById();
                        break;
                    case 4:
                        while(true)
                        {
                            Console.WriteLine("1.Update repair id");
                            Console.WriteLine("2.Update part id");
                            Console.WriteLine("3.Update quantity");
                            Console.WriteLine("4.Exit");
                            int numUpdate = int.Parse(Console.ReadLine());
                            if(numUpdate == 4)
                            {
                                break;
                            }
                            switch (numUpdate)
                            {
                                case 1:
                                    await UpdateRepairId();
                                    break;
                                case 2:
                                    await UpdatePartId();
                                    break;
                                case 3:
                                    await UpdateQuantity();
                                    break;
                            }
                        }
                        break;
                    case 5:
                        await RepairsContainingGivenPart();
                        break;
                }
            }
        }
    }
}
