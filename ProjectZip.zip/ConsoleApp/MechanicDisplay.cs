﻿using Core;
using Data.Models;
using Microsoft.EntityFrameworkCore.Query.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class MechanicDisplay
    {
        MechanicController mechanicController = new MechanicController();
        public async Task AddMechanic()
        {
            Console.WriteLine("Enter mechanic fisrt name: ");
            string firstName = Console.ReadLine();
            Console.WriteLine("Enter mechanic last name: ");
            string lastName = Console.ReadLine();
            Console.WriteLine("Enter mechanic specialization: ");
            string specialization = Console.ReadLine();
            await mechanicController.AddMechanic(firstName, lastName, specialization);
            Console.WriteLine("Mechanic was added successfully!");
        }
        public async Task ViewAllMechanic()
        {
            List<Mechanics> mechanics = await mechanicController.GetAllMechanics();
            foreach(var mechanic in mechanics)
            {
                Console.WriteLine($"{mechanic.mechanic_id}. {mechanic.first_name} {mechanic.last_name}. Specialized in {mechanic.specialization}");
            }
        }
        public async Task RemoveMechanicById()
        {
            Console.WriteLine("Enter mechanic id to remove: ");
            int id = int.Parse(Console.ReadLine());
            await mechanicController.RemoveMechanicById(id);
            Console.WriteLine("Mechanic was remove successfully!");
        }
        public async Task UpdateMechanicFirstName()
        {
            Console.WriteLine("Enter mechanic id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter mechanic new first name: ");
            string firstName = Console.ReadLine();
            await mechanicController.UpdateMechanicFirstName(id, firstName);
            Console.WriteLine("Mechanic first name was changed successfully!");
        }
        public async Task UpdateMechanicLastName()
        {
            Console.WriteLine("Enter mechanic id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter mechanic new last name: ");
            string lastName = Console.ReadLine();
            await mechanicController.UpdateMechanicLastName(id, lastName);
            Console.WriteLine("Mechanic last name was changed successfully!");
        }
        public async Task UpdateMechanicSpecialization()
        {
            Console.WriteLine("Enter mechanic id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter mechanic new specialization: ");
            string specialization = Console.ReadLine();
            await mechanicController.UpdateMechanicSpecialization(id, specialization);
            Console.WriteLine("Mechanic specialization was changed successfully!");
        }
        public async Task BusiestMechanic()
        {
            Mechanics mechanic = await mechanicController.BusiestMechanic();
            Console.WriteLine($"{mechanic.first_name} {mechanic.last_name}");
        }
        public async Task MechanicMenu()
        {
            while(true)
            {
                Console.WriteLine("1.Add mechanic");
                Console.WriteLine("2.View all mechanics");
                Console.WriteLine("3.Remove mechanic by id");
                Console.WriteLine("4.Update mechanic: ");
                Console.WriteLine("5.View the busiest mechanic");
                Console.WriteLine("6.Exit");
                int num = int.Parse(Console.ReadLine());
                if(num == 6)
                {
                    break;
                }
                switch (num)
                {
                    case 1:
                        await AddMechanic();
                        break;
                    case 2:
                        await ViewAllMechanic();
                        break;
                    case 3:
                        await RemoveMechanicById();
                        break;
                    case 4:
                        while(true)
                        {
                            Console.WriteLine("1.Update mechanic first name");
                            Console.WriteLine("2.Update mechanic last name");
                            Console.WriteLine("3.Update mechanic specialization");
                            Console.WriteLine("4.Exit");
                            int numUpdate = int.Parse(Console.ReadLine());
                            if(numUpdate == 4)
                            {
                                break;
                            }
                            switch (numUpdate)
                            {
                                case 1:
                                    await UpdateMechanicFirstName();
                                    break;
                                case 2:
                                    await UpdateMechanicLastName();
                                    break;
                                case 3:
                                    await UpdateMechanicSpecialization();
                                    break;
                            }

                        }
                        break;
                    case 5:
                        await BusiestMechanic();
                        break;

                }

            }
        }
    }
}
