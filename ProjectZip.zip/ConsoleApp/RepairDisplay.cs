﻿using Core;
using Data.Models;
using Microsoft.Identity.Client.Kerberos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class RepairDisplay
    {
        RepairController repairController = new RepairController();
        public async Task AddRepair()
        {
            Console.WriteLine("Enter reapir date in: ");
            DateOnly dateIn = DateOnly.Parse(Console.ReadLine());
            Console.WriteLine("Enter repair date out: ");
            DateOnly dateOut = DateOnly.Parse(Console.ReadLine());
            Console.WriteLine("Enter repair total cost: ");
            double totalCost = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter repair type: ");
            string type = Console.ReadLine();
            Console.WriteLine("Enter repair vehicle id: ");
            int vehicleId = int.Parse(Console.ReadLine());
            await repairController.AddRepair(dateIn, dateOut, totalCost, type, vehicleId);
            Console.WriteLine("Repair was added successfully!");
        }
        public async Task ViewAllRepairs()
        {
            List<Repairs> repairs = await repairController.ViewAllReapirs();
            foreach (var repair in repairs)
            {
                Console.WriteLine($"{repair.repair_id}. Entered on: {repair.date_in}. Out on: {repair.date_out}. Reapir type: {repair.repair_type} - {repair.total_cost} lv.");
            }
        }
        public async Task RemoveRepairById()
        {
            Console.WriteLine("Enter repair id to remove: ");
            int id = int.Parse(Console.ReadLine());
            await repairController.RemoveReapirById(id);
            Console.WriteLine("Repair was remove successfully!");
        }
        public async Task UpdateRepairDateIn()
        {
            Console.WriteLine("Enter repair id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter repair new date in: ");
            DateOnly dateIn = DateOnly.Parse(Console.ReadLine());
            await repairController.UpdateRepairDateIn(id, dateIn);
            Console.WriteLine("Repair date in was changed successfully!");
        }
        public async Task UpdateRepairDateOut()
        {
            Console.WriteLine("Enter repair id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter repair new date out: ");
            DateOnly dateOut = DateOnly.Parse(Console.ReadLine());
            await repairController.UpdateRepairDateOut(id, dateOut);
            Console.WriteLine("Repair date out was changed successfully!");
        }
        public async Task UpdateRepairTotalCost()
        {
            Console.WriteLine("Enter repair id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter repair new total cost: ");
            double totalCost = double.Parse(Console.ReadLine());
            await repairController.UpdateRepairTotalCost(id, totalCost);
            Console.WriteLine("Repair total cost was changed successfully!");
        }
        public async Task UpdateRepairType()
        {
            Console.WriteLine("Enter repair id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter repair new type: ");
            string type = Console.ReadLine();
            await repairController.UpdateRepairType(id, type);
            Console.WriteLine("Repair type was changed successfully!");
        }
        public async Task UpdateRepairVehicleId()
        {

            Console.WriteLine("Enter repair id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter repair new vehicle id: ");
            int vehicleId = int.Parse(Console.ReadLine());
            await repairController.UpdateRepairVehicleId(id, vehicleId);
            Console.WriteLine("Repair vehicle id was changed successfully!");
        }
        public async Task AllRepairsForVehicle()
        {
            Console.WriteLine("Enter id of the vehicle you want to see the repairs for: ");
            int id = int.Parse(Console.ReadLine());
            List<Repairs> repairs = await repairController.AllRepairsForVehcile(id);
            foreach (var repair in repairs)
            {
                Console.WriteLine($"{repair.repair_type} - {repair.total_cost}");
            }
        }
        public async Task TotalCostOfRepairsForClient()
        {
            Console.WriteLine("Enter the id of the client for whom you want to see the total cost of repairs: ");
            int id = int.Parse(Console.ReadLine());
            double totalCost = await repairController.TotalCostOfRepairsForClient(id);
            Console.WriteLine($"Total cost of repairs is: {totalCost}");
        }
        public async Task TotalCostOfRepairsForYear()
        {
            Console.WriteLine("Enter the year you want to see the total cost of repairs: ");
            int year = int.Parse(Console.ReadLine());
            double totalCost = await repairController.TotalCostOfRepairsForYear(year);
            Console.WriteLine($"Toatl cost of repairs for {year} year is {totalCost}.");
        }
        public async Task RepairMenu()
        {
            while(true)
            {
                Console.WriteLine("1.Add repair");
                Console.WriteLine("2.View all repairs");
                Console.WriteLine("3.Remove repair by id");
                Console.WriteLine("4.Update repair: ");
                Console.WriteLine("5.View all repairs for vehicle");
                Console.WriteLine("6.Total cost or repairs for certain client");
                Console.WriteLine("7.Toatl cost of repairs for certain year");
                Console.WriteLine("8.Exit");
                int num = int.Parse(Console.ReadLine());
                if(num == 8)
                {
                    break;
                }
                switch (num)
                {
                    case 1:
                        await AddRepair();
                        break;
                    case 2:
                        await ViewAllRepairs();
                        break;
                    case 3:
                        await RemoveRepairById();
                        break;
                    case 4:
                        while(true)
                        {
                            Console.WriteLine("1.Update repair date in");
                            Console.WriteLine("2.Update repair date out");
                            Console.WriteLine("3.Update repair total cost");
                            Console.WriteLine("4.Update repair type");
                            Console.WriteLine("5.Update repair vehicle id");
                            Console.WriteLine("6.Exit");
                            int numUpdate = int.Parse(Console.ReadLine());
                            if(numUpdate == 6)
                            {
                                break;
                            }
                            switch (numUpdate)
                            {
                                case 1:
                                    await UpdateRepairDateIn();
                                    break;
                                case 2:
                                    await UpdateRepairDateOut();
                                    break;
                                case 3:
                                    await UpdateRepairTotalCost();
                                    break;
                                case 4:
                                    await UpdateRepairType();
                                    break;
                                case 5:
                                    await UpdateRepairVehicleId();
                                    break;
                            }
                        }
                        break;
                    case 5:
                        await AllRepairsForVehicle();
                        break;
                    case 6:
                        await TotalCostOfRepairsForClient();
                        break;
                    case 7:
                        await TotalCostOfRepairsForYear();
                        break;
                }

            }
        }

    }
}
