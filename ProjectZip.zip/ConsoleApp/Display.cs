﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class Display
    {
        ClientDisplay clientDisplay = new ClientDisplay();
        MechanicDisplay mechanicDisplay = new MechanicDisplay();
        PartDisplay partDisplay = new PartDisplay();
        RepairDisplay repairDisplay = new RepairDisplay();
        VehicleDisplay vehicleDisplay = new VehicleDisplay();
        RepairMechanicDisplay repairMechanicDisplay = new RepairMechanicDisplay();
        RepairPartDisplay repairPartDisplay = new RepairPartDisplay();
        public async Task Menu()
        {
            while(true)
            {
                Console.WriteLine("Choose table you want to process: ");
                Console.WriteLine("1.Cleints");
                Console.WriteLine("2.Mechanics");
                Console.WriteLine("3.Vehicles");
                Console.WriteLine("4.Parts");
                Console.WriteLine("5.Repairs");
                Console.WriteLine("6.Repair mechanic");
                Console.WriteLine("7.Repair part");
                Console.WriteLine("8.Exit");
                int num = int.Parse(Console.ReadLine());
                while(num == 8)
                {
                    break;
                }
                switch (num)
                {
                    case 1:
                        await clientDisplay.ClientMenu();
                        break;
                    case 2:
                        await mechanicDisplay.MechanicMenu();
                        break;
                    case 3:
                        await vehicleDisplay.VehicleMenu();
                        break;
                    case 4:
                        await partDisplay.PartMenu();
                        break;
                    case 5:
                        await repairDisplay.RepairMenu();
                        break;
                    case 6:
                        await repairMechanicDisplay.RepairMechanicMenu();
                        break;
                    case 7:
                        await repairPartDisplay.RepairPartMenu();
                        break;
                }
            }
        }
    }
}
