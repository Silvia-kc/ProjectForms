﻿using Core;
using Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class VehicleDisplay
    {
        VehicleController vehicleController = new VehicleController();
        public async Task AddVehicle()
        {
            Console.WriteLine("Enter vehicle brand: ");
            string brand = Console.ReadLine();
            Console.WriteLine("Enter vehicl model: ");
            string model = Console.ReadLine();
            Console.WriteLine("Enter vehicle year of manifacture: ");
            int yearOfManifacture = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter vheicle license plate: ");
            string licensePlate = Console.ReadLine();
            Console.WriteLine("Enter vehicle client id: ");
            int clientId = int.Parse(Console.ReadLine());
            await vehicleController.AddVehicle(brand, model, yearOfManifacture, licensePlate, clientId);
            Console.WriteLine("Vehicle was added successfully!");
        }
        public async Task ViewAllVehicles()
        {
            List<Vehicles> vehicles = await vehicleController.ViewAllVehicles();
            foreach (var vehicle in vehicles)
            {
                Console.WriteLine($"{vehicle.vehicle_id}. {vehicle.brand} {vehicle.model} manufactured in {vehicle.year_of_manifacture}. Vehicle with license plate {vehicle.license_plate} belongiong to client wit id {vehicle.client_id}");
            }
        }
        public async Task RemoveVehicleById()
        {
            Console.WriteLine("Enter vehicle id to remove: ");
            int id = int.Parse(Console.ReadLine());
            await vehicleController.RemoveVehicleById(id);
            Console.WriteLine("Vehicle was remove successfully!");
        }
        public async Task UpdateVehicleBrand()
        {
            Console.WriteLine("Enter vehicle id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter vehicle new brand: ");
            string brand = Console.ReadLine();
            await vehicleController.UpdateVehicleBrand(id, brand);
            Console.WriteLine("Vehicle brand was changed successfully!");
        }
        public async Task UpdateVehicleModel()
        {
            Console.WriteLine("Enter vehicle id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter vehicle new model: ");
            string model = Console.ReadLine();
            await vehicleController.UpdateVehicleModel(id, model);
            Console.WriteLine("Vehicle model was changed successfully!");
        }
        public async Task UpdateVehicleYearOfManifacture()
        {
            Console.WriteLine("Enter vehicle id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter vehicle new year of manifacture: ");
            int yearOfManifacture = int.Parse(Console.ReadLine());
            await vehicleController.UpdateVehicleYearOfManifacture(id, yearOfManifacture);
            Console.WriteLine("Vehicle year of manifacture was changed successfully!");
        }
        public async Task UpdateVehicleLicensePlate()
        {
            Console.WriteLine("Enter vehicle id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter vehicle new license plate: ");
            string licensePlate = Console.ReadLine();
            await vehicleController.UpdateVehicleLicensePlate(id, licensePlate);
            Console.WriteLine("Vehicle license plate was changed successfully!");
        }
        public async Task UpdateVehicleClientId()
        {
            Console.WriteLine("Enter vehicle id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter vehicle new client id: ");
            int clientId = int.Parse(Console.ReadLine());
            await vehicleController.UpdateVehicleClientId(id, clientId);
            Console.WriteLine("Vehicle client id was changed successfully!");
        }
        public async Task AllClientVehicle()
        {
            Console.WriteLine("Еnter the id of the client whose vehicles you want to see");
            int id = int.Parse(Console.ReadLine());
            List<Vehicles> vehicles = await vehicleController.AllClientVehicles(id);
            foreach(var vehicle in vehicles)
            {
                Console.WriteLine($"{vehicle.brand} {vehicle.model} - {vehicle.license_plate}");
            }
        }
        public async Task MostVisistedCarBrand()
        {
            string brand = await vehicleController.MostVisitedCarBrand();
            Console.WriteLine($"The brand that visited the service station most often is {brand}");
        }
        public async Task VehicleMenu()
        {
            while(true)
            {
                Console.WriteLine("1.Add vehicle");
                Console.WriteLine("2.Remove vehicle by id");
                Console.WriteLine("3.Update vehicle: ");
                Console.WriteLine("4.See all vehicles of a certain client");
                Console.WriteLine("5.The brand that most often visits the car service");
                Console.WriteLine("6.Exit");
                int num = int.Parse(Console.ReadLine());
                if(num == 6)
                {
                    break;
                }
                switch (num)
                {
                    case 1:
                        await AddVehicle();
                        break;
                    case 2:
                        await RemoveVehicleById();
                        break;
                    case 3:
                        while(true)
                        {
                            Console.WriteLine("1.Update vehicle brand");
                            Console.WriteLine("2.Update vehicle model");
                            Console.WriteLine("3.Update vehicle year of manifacture");
                            Console.WriteLine("4.Update vehicle license plate");
                            Console.WriteLine("5.Update vehicle client id");
                            Console.WriteLine("6.Exit");
                            int numUpdate = int.Parse(Console.ReadLine());
                            if(numUpdate == 6)
                            {
                                break;
                            }
                            switch (numUpdate)
                            {
                                case 1:
                                    await UpdateVehicleBrand();
                                    break;
                                case 2:
                                    await UpdateVehicleModel();
                                    break;
                                case 3:
                                    await UpdateVehicleYearOfManifacture();
                                    break;
                                case 4:
                                    await UpdateVehicleLicensePlate(); 
                                    break;
                                case 5:
                                    await UpdateVehicleClientId();
                                    break;
                            }
                        }
                        break;
                    case 4:
                        await AllClientVehicle();
                        break;
                    case 5:
                        await MostVisistedCarBrand();
                        break;
                }
            }
        }
    }
}
