﻿using Core;
using Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class RepairMechanicDisplay
    {
        RepairMechanicController repairMechanicController = new RepairMechanicController();
        public async Task AddRepairMechanic()
        {
            Console.WriteLine("Enter repair id: ");
            int repairId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter mechanic id: ");
            int mechanicId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter working hourts: ");
            int workingHours = int.Parse(Console.ReadLine());
            await repairMechanicController.AddRepairMechanic(repairId, mechanicId, workingHours);
            Console.WriteLine("Addidng was successful!");
        }
        public async Task ViewAllRepairMechanic()
        {
            List<RepairMechanics> repairMechanics = await repairMechanicController.ViewAllRepairMechanics();
            foreach(var repairMechanic in repairMechanics)
            {
                Console.WriteLine($"Repair id: {repairMechanic.repair_id}. Mechanic id: {repairMechanic.mechanic_id}. Hours worked on the repair {repairMechanic.working_hours}");
            }
        }
        public async Task RemoveRepairMechanicById()
        {
            Console.WriteLine("Enter repair id to remove: ");
            int repiarId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter mechanic id to remove: ");
            int mechanicId = int.Parse(Console.ReadLine());
            await repairMechanicController.RemoveRepairMechanicById(repiarId, mechanicId);
            Console.WriteLine("Removal was successful!");
        }
        public async Task UpdateRepairId()
        {
            Console.WriteLine("Enter repair id for update: ");
            int repairId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter mechanic id for update: ");
            int mechanicId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter new repair id: ");
            int newId = int.Parse(Console.ReadLine());
            await repairMechanicController.UpdateRepairId(repairId, mechanicId, newId);
        }
        public async Task UpdateMechanicId()
        {
            Console.WriteLine("Enter mechanic id for update: ");
            int mechanicId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter repair id for update: ");
            int repairId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter new mechanic id: ");
            int newId = int.Parse(Console.ReadLine());
            await repairMechanicController.UpdateMechanicId(repairId, mechanicId, newId);
        }
        public async Task UpdateWorkingHours()
        {
            Console.WriteLine("Enter repair id for update: ");
            int repairId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter mechanic id for update: ");
            int mechanicId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter new working hours: ");
            int workingHours = int.Parse(Console.ReadLine());
            await repairMechanicController.UpdateWorkingHours(repairId, mechanicId, workingHours);
        }
        public async Task MechanicWorkedOnAGivenRepair()
        {
            Console.WriteLine("Enter repair id: ");
            int id = int.Parse(Console.ReadLine());
            List<Mechanics> mechanics = await repairMechanicController.MechanicWorkedOnAGivenRepair(id);
            foreach (var mechanic in mechanics)
            {
                Console.WriteLine($"{mechanic.first_name} {mechanic.last_name}");
            }
        }
        public async Task RepairMechanicMenu()
        {
            while(true)
            {
                Console.WriteLine("1.Add to repair mechanic");
                Console.WriteLine("2.View all from repair mechanic");
                Console.WriteLine("3.Remove from repair mechanic by id");
                Console.WriteLine("4.Update from repair mechanic: ");
                Console.WriteLine("5.View mechanics who worked on a given repair");
                Console.WriteLine("6.Exit");
                int num = int.Parse(Console.ReadLine());
                if(num == 6)
                {
                    break;
                }
                switch (num)
                {
                    case 1:
                        await AddRepairMechanic();
                        break;
                    case 2:
                        await ViewAllRepairMechanic();
                        break;
                    case 3:
                        await RemoveRepairMechanicById();
                        break;
                    case 4:
                        while(true)
                        {
                            Console.WriteLine("1.Update repair id");
                            Console.WriteLine("2.Update mechanic id");
                            Console.WriteLine("3.Update working hours");
                            Console.WriteLine("4.Exit");
                            int numUpdate = int.Parse(Console.ReadLine());
                            if(numUpdate == 4)
                            {
                                break;
                            }
                            switch (numUpdate)
                            {
                                case 1:
                                    await UpdateRepairId();
                                    break;
                                case 2:
                                    await UpdateMechanicId();
                                    break;
                                case 3:
                                    await UpdateWorkingHours();
                                    break;
                            }
                        }
                        break;
                    case 5:
                        await MechanicWorkedOnAGivenRepair();
                        break;
                }
            }
        }
    }
}
