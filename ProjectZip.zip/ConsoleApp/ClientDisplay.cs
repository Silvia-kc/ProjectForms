﻿using Core;
using Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class ClientDisplay
    {
        ClientController clientController = new ClientController();
        public async Task AddClient()
        {
            Console.WriteLine("Enter client first name: ");
            string firstName = Console.ReadLine();
            Console.WriteLine("Enter last name: ");
            string lastName = Console.ReadLine();
            Console.WriteLine("Enter client phone number: ");
            string phoneNumber = Console.ReadLine();
            Console.WriteLine("Enter client email: ");
            string email = Console.ReadLine();
            await clientController.AddClient(firstName, lastName, phoneNumber, email);
            Console.WriteLine("Client was added successfully!");
        }
        public async Task ViewAllClients()
        {
            List<Clients> clients = await clientController.GetAllClients();
            foreach (var client in clients)
            {
                Console.WriteLine($"{client.client_Id}. {client.first_name} {client.last_name}. Client contact: phone numebr: {client.phone_number}, email: {client.email}");
            }
        }
        public async Task RemoveClientById()
        {
            Console.WriteLine("Enter client id to remove: ");
            int id = int.Parse(Console.ReadLine());
            await clientController.RemoveClientById(id);
            Console.WriteLine("Client was remove successfully!");
        }
        public async Task UpdateClientFirstName()
        {
            Console.WriteLine("Enter client id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter client new first name: ");
            string firstName = Console.ReadLine();
            await clientController.UpdateClientFirstName(id, firstName);
            Console.WriteLine("Client first name was changed successfully!");
        }
        public async Task UpdateClientLastName()
        {
            Console.WriteLine("Enter client id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter client new last name: ");
            string lastName = Console.ReadLine();
            await clientController.UpdateClientLastName(id, lastName);
            Console.WriteLine("Client last name was changed successfully!");
        }
        public async Task UpdateClientPhoneNumber()
        {
            Console.WriteLine("Enter client id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter client new phone number: ");
            string phoneNumber = Console.ReadLine();
            await clientController.UpdateClientPhoneNumber(id, phoneNumber);
            Console.WriteLine("Client phone number was changed successfully!");
        }
        public async Task UpdateClientEmail()
        {
            Console.WriteLine("Enter client id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter client new email: ");
            string email = Console.ReadLine();
            await clientController.UpdateClientEmail(id, email);
            Console.WriteLine("Client email was changed successfully!");
        }
        public async Task SearchClientByFirstName()
        {
            Console.WriteLine("Enter client first name for search: ");
            string firstName = Console.ReadLine();
            Clients clients = await clientController.SearchClientByFirstName(firstName);
            Console.WriteLine($"{clients.client_Id}. {clients.first_name} {clients.last_name}. Client contact: phone numebr: {clients.phone_number}, email: {clients.email}");
        }
        public async Task ClientMenu()
        {
            while (true)
            {
                Console.WriteLine("1.Add client");
                Console.WriteLine("2.View all clients");
                Console.WriteLine("3.Remove client by id");
                Console.WriteLine("4.Update client: ");
                Console.WriteLine("5.Search client by first name");
                Console.WriteLine("6.Exit");
                int num = int.Parse(Console.ReadLine());
                if (num == 6)
                {
                    break;
                }
                switch (num)
                {
                    case 1:
                        await AddClient();
                        break;
                    case 2:
                        await ViewAllClients();
                        break;
                    case 3:
                        await RemoveClientById();
                        break;
                    case 4:
                        while (true)
                        {
                            Console.WriteLine("1.Update client first name");
                            Console.WriteLine("2.Update client last name");
                            Console.WriteLine("3.Update client phone number");
                            Console.WriteLine("4.Update client email");
                            Console.WriteLine("5.Exit");
                            int numUpdate = int.Parse(Console.ReadLine());
                            if (numUpdate == 5)
                            {
                                break;
                            }
                            switch (numUpdate)
                            {
                                case 1:
                                    await UpdateClientFirstName();
                                    break;
                                case 2:
                                    await UpdateClientLastName();
                                    break;
                                case 3:
                                    await UpdateClientPhoneNumber();
                                    break;
                                case 4:
                                    await UpdateClientEmail();
                                    break;
                            }
                        }
                        break;
                    case 5:
                        await SearchClientByFirstName();
                        break;
                }
            }
        }
    }
}
