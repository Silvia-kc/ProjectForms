﻿using Core;
using Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class PartDisplay
    {
        PartController partController = new PartController();
        public async Task AddPart()
        {
            Console.WriteLine("Enter part name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter part price: ");
            double price = double.Parse(Console.ReadLine());
            await partController.AddPart(name, price);
            Console.WriteLine("Part was added successfully!");
        }
        public async Task ViewAllParts()
        {
            List<Parts> parts = await partController.GetAllParts();
            foreach(var part in parts)
            {
                Console.WriteLine($"{part.part_id}. {part.name} - {part.price} lv.");
            }
        }
        public async Task RemovePartById()
        {
            Console.WriteLine("Enter part id to remove: ");
            int id = int.Parse(Console.ReadLine());
            await partController.RemovePartById(id);
            Console.WriteLine("Part was remove successfully!");
        }
        public async Task UpdatePartName()
        {
            Console.WriteLine("Enter part id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter part new name: ");
            string name = Console.ReadLine();
            await partController.UpdatePartName(id, name);
            Console.WriteLine("Part name was changed successfully!");
        }
        public async Task UpdatePartPrice()
        {
            Console.WriteLine("Enter part id for update: ");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter part new price: ");
            double price = double.Parse(Console.ReadLine());
            await partController.UpdatePartPrice(id, price);
            Console.WriteLine("Part price was changed successfully!");
        }
        public async Task MostUsedPart()
        {
            Parts part = await partController.MostCommonlyUsedPart();
            Console.WriteLine($"{part.name} - {part.price}");
        }
        public async Task PartMenu()
        {
            while(true)
            {
                Console.WriteLine("1.Add part");
                Console.WriteLine("2.View all parts");
                Console.WriteLine("3.Remove part by id");
                Console.WriteLine("4.Update part: ");
                Console.WriteLine("5.View the most used part");
                Console.WriteLine("56.Exit");
                int num = int.Parse(Console.ReadLine());
                if(num == 6)
                {
                    break;
                }
                switch(num)
                {
                    case 1:
                        await AddPart();
                        break;
                    case 2:
                        await ViewAllParts();
                        break;
                    case 3:
                        await RemovePartById();
                        break;
                    case 4:
                        while(true)
                        {
                            Console.WriteLine("1.Update part name");
                            Console.WriteLine("2.Update part price");
                            Console.WriteLine("3.Exit");
                            int numUpdate = int.Parse(Console.ReadLine());
                            if(numUpdate == 3)
                            {
                                break;
                            }
                            switch (numUpdate)
                            {
                                case 1:
                                    await UpdatePartName();
                                    break;
                                case 2:
                                    await UpdatePartPrice();
                                    break;
                            }
                        }
                        break;
                    case 5:
                        await MostUsedPart();
                        break;
                }

            }
        }
    }
}
