﻿using Core;
using Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class Program
    {
        static async Task Main(string[] args)
        {
            CarServiceDBContext context = new CarServiceDBContext();
            ImportFiles importFiles = new ImportFiles(context);
            await importFiles.Clients();
            await importFiles.Vehicles();
            await importFiles.Repairs();
            await importFiles.Mechanics();
            await importFiles.Parts();
            await importFiles.RepairMechanics();
            await importFiles.RepairParts();
            Display display = new Display();
            await display.Menu();
        }
    }
}
